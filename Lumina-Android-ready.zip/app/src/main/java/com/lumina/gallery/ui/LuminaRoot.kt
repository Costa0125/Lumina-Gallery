package com.lumina.gallery.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.PhotoAlbum
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lumina.gallery.data.MediaFile
import com.lumina.gallery.data.Source
import com.lumina.gallery.player.VideoPlayerActivity
import com.lumina.gallery.ui.theme.LuminaTheme

// ------------------------------------------------------------------------------------------
// Permisos de medios (solo lectura; borrar/mover pasa siempre por diálogos del sistema)
// ------------------------------------------------------------------------------------------

private enum class Access { NONE, PARTIAL, FULL }

private fun mediaPermissions(): Array<String> = when {
    Build.VERSION.SDK_INT >= 34 -> arrayOf(
        Manifest.permission.READ_MEDIA_IMAGES,
        Manifest.permission.READ_MEDIA_VIDEO,
        Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED,
    )
    Build.VERSION.SDK_INT >= 33 -> arrayOf(
        Manifest.permission.READ_MEDIA_IMAGES,
        Manifest.permission.READ_MEDIA_VIDEO,
    )
    else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
}

private fun currentAccess(context: android.content.Context): Access {
    fun ok(p: String) = ContextCompat.checkSelfPermission(context, p) == PackageManager.PERMISSION_GRANTED
    return if (Build.VERSION.SDK_INT >= 33) {
        when {
            ok(Manifest.permission.READ_MEDIA_IMAGES) && ok(Manifest.permission.READ_MEDIA_VIDEO) -> Access.FULL
            Build.VERSION.SDK_INT >= 34 && ok(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) -> Access.PARTIAL
            else -> Access.NONE
        }
    } else {
        if (ok(Manifest.permission.READ_EXTERNAL_STORAGE)) Access.FULL else Access.NONE
    }
}

@Composable
fun LuminaRoot(vm: MainViewModel = viewModel()) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    LuminaTheme(settings.themeMode) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            PermissionGate(vm)
        }
    }
}

@Composable
private fun PermissionGate(vm: MainViewModel) {
    val context = LocalContext.current
    var access by remember { mutableStateOf(currentAccess(context)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        access = currentAccess(context)
        vm.onPermissionChanged()
    }
    // Al volver de los ajustes del sistema se vuelve a comprobar el permiso.
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                val now = currentAccess(context)
                if (now != access) {
                    access = now
                    vm.onPermissionChanged()
                }
            }
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }

    if (access == Access.NONE) {
        PermissionScreen(
            onGrant = { launcher.launch(mediaPermissions()) },
            onOpenSettings = {
                context.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null)),
                )
            },
        )
    } else {
        MainContent(vm, partial = access == Access.PARTIAL, requestAll = { launcher.launch(mediaPermissions()) })
    }
}

@Composable
private fun PermissionScreen(onGrant: () -> Unit, onOpenSettings: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(Icons.Rounded.PhotoLibrary, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(64.dp))
        Text(
            "Tus recuerdos, solo en tu teléfono",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 20.dp),
        )
        Text(
            "Lumina necesita leer tus fotos y vídeos para mostrarlos. Nada se sube a Internet: la app ni siquiera " +
                "tiene permiso de red. Para borrar o mover archivos, Android siempre te pedirá confirmación.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            fontSize = 15.sp,
            modifier = Modifier.padding(top = 12.dp, bottom = 28.dp),
        )
        Button(onClick = onGrant) { Text("Permitir acceso a fotos y vídeos") }
        OutlinedButton(onClick = onOpenSettings, modifier = Modifier.padding(top = 8.dp)) {
            Text("Abrir ajustes de la aplicación")
        }
    }
}

// ------------------------------------------------------------------------------------------
// Navegación: 4 pestañas + páginas superpuestas (ajustes, papelera, carpeta, álbum) + visor
// ------------------------------------------------------------------------------------------

private sealed interface Page {
    data object Settings : Page
    data class Grid(val source: Source, val title: String) : Page
}

@Composable
private fun MainContent(vm: MainViewModel, partial: Boolean, requestAll: () -> Unit) {
    val context = LocalContext.current
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var page by remember { mutableStateOf<Page?>(null) }

    val photosState = androidx.compose.foundation.lazy.grid.rememberLazyGridState()
    val videosState = androidx.compose.foundation.lazy.grid.rememberLazyGridState()
    val favoritesState = androidx.compose.foundation.lazy.grid.rememberLazyGridState()
    val albumsState = androidx.compose.foundation.lazy.grid.rememberLazyGridState()

    val media by vm.media.collectAsStateWithLifecycle()
    val userData by vm.userData.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()

    BackHandler(enabled = page != null) { page = null }
    BackHandler(enabled = page == null && tab != 0 && vm.viewer == null) { tab = 0 }

    val open: (MediaFile, List<MediaFile>) -> Unit = { file, list ->
        if (file.isVideo) {
            context.startActivity(VideoPlayerActivity.intent(context, file.uri, file.name, file.positionKey))
        } else {
            val photos = list.filter { !it.isVideo }
            vm.viewer = ViewerSession(photos.map { it.id }, photos.indexOfFirst { it.id == file.id }.coerceAtLeast(0))
        }
    }

    val resumeItems = remember(media, userData.positions, settings.resume) {
        if (!settings.resume) {
            emptyList()
        } else {
            media.filter { it.isVideo }.mapNotNull { f ->
                userData.positions[f.positionKey]
                    ?.takeIf { it.durationMs > 0 && it.positionMs > 3_000 && it.positionMs < it.durationMs - 5_000 }
                    ?.let { f to it }
            }.sortedByDescending { it.second.updatedAt }.take(10)
        }
    }
    val resumeHeader: (@Composable () -> Unit)? = if (resumeItems.isEmpty()) null else {
        { ContinueWatchingRow(resumeItems) { f -> open(f, listOf(f)) } }
    }
    val partialHeader: (@Composable () -> Unit)? = if (!partial) null else {
        { PartialAccessBanner(requestAll) }
    }

    val openSettings = { page = Page.Settings }
    val openTrash = { page = Page.Grid(Source.Trash, "Papelera") }

    Box(Modifier.fillMaxSize()) {
        // Contenido de la pestaña activa (sin fundidos entre pestañas: evita componer dos cuadrículas a la vez).
        val barSpace = 104.dp
        Box(Modifier.fillMaxSize()) {
            when (tab) {
                0 -> MediaGridScreen(
                    vm, Source.Photos, "Fotos", photosState, open,
                    onOpenSettings = openSettings, onOpenTrash = openTrash, header = partialHeader,
                    bottomPadding = barSpace,
                )
                1 -> AlbumsScreen(
                    vm, albumsState,
                    onOpenSource = { src ->
                        page = Page.Grid(
                            src,
                            when (src) {
                                is Source.Folder -> src.name
                                is Source.Album -> src.name
                                else -> ""
                            },
                        )
                    },
                    onOpenSettings = openSettings,
                    onOpenTrash = openTrash,
                    bottomPadding = barSpace,
                )
                2 -> MediaGridScreen(
                    vm, Source.Videos, "Vídeos", videosState, open,
                    onOpenSettings = openSettings, onOpenTrash = openTrash, header = resumeHeader,
                    bottomPadding = barSpace,
                )
                else -> MediaGridScreen(
                    vm, Source.Favorites, "Favoritos", favoritesState, open,
                    onOpenSettings = openSettings, onOpenTrash = openTrash,
                    bottomPadding = barSpace,
                )
            }

            // Barra inferior flotante en forma de píldora; se oculta al seleccionar.
            AnimatedVisibility(
                visible = vm.selection.isEmpty(),
                enter = slideInVertically(tween(200)) { it } + fadeIn(tween(200)),
                exit = slideOutVertically(tween(160)) { it } + fadeOut(tween(160)),
                modifier = Modifier.align(Alignment.BottomCenter),
            ) {
                FloatingNavBar(tab = tab, onTab = { tab = it })
            }
        }

        // Páginas superpuestas con transición lateral.
        AnimatedContent(
            targetState = page,
            transitionSpec = {
                if (targetState != null) {
                    (slideInHorizontally(tween(260)) { it / 4 } + fadeIn(tween(260))) togetherWith fadeOut(tween(120))
                } else {
                    fadeIn(tween(120)) togetherWith (slideOutHorizontally(tween(220)) { it / 4 } + fadeOut(tween(220)))
                }
            },
            label = "page",
        ) { p ->
            when (p) {
                null -> Unit
                Page.Settings -> Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    SettingsScreen(vm, onBack = { page = null })
                }
                is Page.Grid -> Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    GridPage(vm, p, open, onClose = { page = null })
                }
            }
        }

        // Visor de fotos con animación de apertura.
        AnimatedContent(
            targetState = vm.viewer,
            transitionSpec = { (fadeIn(tween(220)) + scaleIn(tween(220), initialScale = 0.94f)) togetherWith fadeOut(tween(160)) },
            label = "viewer",
        ) { session ->
            if (session != null) PhotoViewer(vm, session, onClose = { vm.viewer = null })
        }
    }
}

@Composable
private fun FloatingNavBar(tab: Int, onTab: (Int) -> Unit) {
    val items = listOf(
        Triple("Fotos", Icons.Rounded.PhotoLibrary, 0),
        Triple("Álbumes", Icons.Rounded.PhotoAlbum, 1),
        Triple("Vídeos", Icons.Rounded.VideoLibrary, 2),
        Triple("Favoritos", Icons.Rounded.Favorite, 3),
    )
    Surface(
        modifier = Modifier.navigationBarsPadding().padding(bottom = 12.dp),
        shape = RoundedCornerShape(34.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.97f),
        tonalElevation = 6.dp,
        shadowElevation = 14.dp,
    ) {
        Row(Modifier.padding(6.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            items.forEach { (label, icon, index) ->
                val selected = tab == index
                Row(
                    Modifier
                        .clip(RoundedCornerShape(28.dp))
                        .background(if (selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                        .clickable { onTab(index) }
                        .padding(horizontal = if (selected) 16.dp else 14.dp, vertical = 11.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        icon, label,
                        tint = if (selected) MaterialTheme.colorScheme.onPrimaryContainer
                        else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    if (selected) {
                        Text(
                            label,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            maxLines = 1,
                            modifier = Modifier.padding(start = 8.dp),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun GridPage(vm: MainViewModel, page: Page.Grid, open: (MediaFile, List<MediaFile>) -> Unit, onClose: () -> Unit) {
    val state = androidx.compose.foundation.lazy.grid.rememberLazyGridState()
    val userData by vm.userData.collectAsStateWithLifecycle()
    val source = page.source
    val isTrash = source == Source.Trash
    var renaming by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }
    val trashOpen: (MediaFile, List<MediaFile>) -> Unit = { f, _ -> vm.toggleSelect(f.id) }

    val title = if (source is Source.Album) {
        userData.albums.firstOrNull { it.id == source.id }?.name ?: page.title
    } else {
        page.title
    }

    Box(Modifier.fillMaxSize().navigationBarsPadding()) {
        MediaGridScreen(
            vm = vm,
            source = source,
            title = title,
            gridState = state,
            // En la papelera, tocar un elemento solo lo selecciona (no se puede abrir un archivo en la papelera).
            onOpen = if (isTrash) trashOpen else open,
            onBack = onClose,
            extraMenu = if (source is Source.Album) {
                { dismiss ->
                    DropdownMenuItem(
                        text = { Text("Cambiar nombre del álbum") },
                        leadingIcon = { Icon(Icons.Rounded.Edit, null) },
                        onClick = { dismiss(); renaming = true },
                    )
                    DropdownMenuItem(
                        text = { Text("Eliminar álbum") },
                        leadingIcon = { Icon(Icons.Rounded.Delete, null) },
                        onClick = { dismiss(); deleting = true },
                    )
                }
            } else {
                null
            },
        )
    }

    if (source is Source.Album) {
        if (renaming) {
            TextInputDialog(
                title = "Cambiar nombre",
                label = "Nombre",
                initial = title,
                onConfirm = { vm.renameAlbum(source.id, it) },
                onDismiss = { renaming = false },
            )
        }
        if (deleting) {
            ConfirmDialog(
                title = "¿Eliminar el álbum «$title»?",
                text = "Solo se elimina el álbum. Las fotos y los vídeos originales NO se borran.",
                confirmLabel = "Eliminar álbum",
                destructive = true,
                onConfirm = { vm.deleteAlbum(source.id); onClose() },
                onDismiss = { deleting = false },
            )
        }
    }
}

@Composable
private fun PartialAccessBanner(requestAll: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp)
            .background(MaterialTheme.colorScheme.secondaryContainer, RoundedCornerShape(16.dp))
            .padding(start = 14.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            "Acceso parcial: solo ves las fotos que elegiste.",
            fontSize = 13.sp,
            modifier = Modifier.weight(1f),
        )
        TextButton(onClick = requestAll) { Text("Permitir todo") }
    }
}
