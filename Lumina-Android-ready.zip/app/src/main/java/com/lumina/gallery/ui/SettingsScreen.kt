package com.lumina.gallery.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.lumina.gallery.data.FrameMode
import com.lumina.gallery.data.SortField
import com.lumina.gallery.data.ThemeMode
import com.lumina.gallery.data.ThumbSize
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(vm: MainViewModel, onBack: () -> Unit, modifier: Modifier = Modifier) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val version = remember {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: "?"
    }

    Column(modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 8.dp).height(64.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Volver") }
            Text("Ajustes", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Group("Apariencia")
            Chips("Tema") {
                ThemeMode.entries.forEach { m ->
                    FilterChip(s.themeMode == m, { vm.editSettings { setTheme(m) } }, { Text(m.label) })
                }
            }
            Chips("Tamaño de las miniaturas") {
                ThumbSize.entries.forEach { t ->
                    FilterChip(s.thumbSize == t, { vm.editSettings { setThumbSize(t) } }, { Text(t.label) })
                }
            }
            Chips("Ordenación predeterminada") {
                SortField.entries.forEach { f ->
                    FilterChip(s.defaultSort == f, { vm.editSettings { setDefaultSort(f) } }, { Text(f.label) })
                }
            }

            Group("Reproductor de vídeo")
            var hide by remember(s.hideSeconds) { mutableFloatStateOf(s.hideSeconds.toFloat()) }
            Column {
                Text("Ocultar controles tras ${hide.roundToInt()} s", fontSize = 15.sp)
                Slider(
                    value = hide,
                    onValueChange = { hide = it },
                    onValueChangeFinished = { vm.editSettings { setHideSeconds(hide.roundToInt()) } },
                    valueRange = 3f..8f,
                    steps = 4,
                )
            }
            Chips("Velocidad predeterminada") {
                listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { v ->
                    FilterChip(
                        selected = kotlin.math.abs(s.defaultSpeed - v) < 0.01f,
                        onClick = { vm.editSettings { setDefaultSpeed(v) } },
                        label = { Text(speedLabel(v)) },
                    )
                }
            }
            Chips("Intervalo de avance y retroceso") {
                listOf(5, 10, 15, 30).forEach { sec ->
                    FilterChip(s.seekSeconds == sec, { vm.editSettings { setSeekSeconds(sec) } }, { Text("$sec s") })
                }
            }
            Chips("Encuadre al abrir un vídeo") {
                listOf(FrameMode.FIT, FrameMode.FILL).forEach { m ->
                    FilterChip(s.frameMode == m, { vm.editSettings { setFrameMode(m) } }, { Text(m.label) })
                }
            }
            SwitchRow(
                "Gestos en pantalla",
                "Brillo (lado izquierdo), volumen (derecho) y doble toque para saltar.",
                s.gestures,
            ) { vm.editSettings { setGestures(it) } }
            SwitchRow(
                "Doble toque en el centro pausa",
                "Solo si los gestos están activados.",
                s.doubleTapCenterPause,
            ) { vm.editSettings { setCenterTap(it) } }
            SwitchRow(
                "Continuar donde lo dejé",
                "Guarda la posición de cada película y muestra «Continuar viendo».",
                s.resume,
            ) { vm.editSettings { setResume(it) } }
            SwitchRow("Vibración", "Respuesta háptica al saltar con doble toque.", s.haptics) {
                vm.editSettings { setHaptics(it) }
            }

            Group("Privacidad y permisos")
            Text(
                "Tus fotos y vídeos nunca salen del teléfono: la aplicación no tiene permiso de Internet, " +
                    "no usa analíticas ni servicios en la nube. Solo pide leer fotos y vídeos; borrar o mover " +
                    "archivos siempre requiere tu confirmación en un cuadro de diálogo del sistema.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 14.sp,
            )
            OutlinedButton(onClick = {
                context.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null)),
                )
            }) { Text("Abrir permisos de la aplicación") }

            Group("Acerca de")
            Text(
                String.format(Locale.US, "Lumina Gallery %s", version),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 14.sp,
                modifier = Modifier.padding(bottom = 32.dp),
            )
        }
    }
}

private fun speedLabel(v: Float): String = String.format(Locale.US, "%.2f", v).trimEnd('0').trimEnd('.') + "×"

@Composable
private fun Group(title: String) {
    Text(
        title,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(top = 10.dp),
    )
}

@Composable
private fun Chips(label: String, chips: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(label, fontSize = 15.sp)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            chips()
        }
    }
}

@Composable
private fun SwitchRow(title: String, description: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, fontSize = 15.sp)
            Text(description, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
