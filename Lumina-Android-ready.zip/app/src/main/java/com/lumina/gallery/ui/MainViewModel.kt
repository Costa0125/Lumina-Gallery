package com.lumina.gallery.ui

import android.app.Application
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.lumina.gallery.data.AlbumInfo
import com.lumina.gallery.data.AppSettings
import com.lumina.gallery.data.Content
import com.lumina.gallery.data.ContentBuilder
import com.lumina.gallery.data.DateFilter
import com.lumina.gallery.data.FolderInfo
import com.lumina.gallery.data.MediaFile
import com.lumina.gallery.data.MediaOps
import com.lumina.gallery.data.MediaRepository
import com.lumina.gallery.data.SettingsRepository
import com.lumina.gallery.data.SortField
import com.lumina.gallery.data.Source
import com.lumina.gallery.data.TypeFilter
import com.lumina.gallery.data.UserData
import com.lumina.gallery.data.UserDataRepository
import com.lumina.gallery.data.ViewOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** Visor de fotos abierto: ids en orden y posición inicial. Los datos se resuelven siempre desde la biblioteca viva. */
data class ViewerSession(val ids: List<Long>, val startIndex: Int)

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val ctx = app.applicationContext
    private val mediaRepo = MediaRepository(ctx)
    private val settingsRepo = SettingsRepository(ctx)
    private val userRepo = UserDataRepository(ctx)

    private val refreshTick = MutableSharedFlow<Unit>(extraBufferCapacity = 1)

    /** Biblioteca (sin papelera). Una sola consulta, repetida solo si el sistema avisa de cambios. */
    val media: StateFlow<List<MediaFile>> =
        mediaRepo.observe(false, refreshTick).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val trash: StateFlow<List<MediaFile>> =
        mediaRepo.observe(true, refreshTick)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val userData: StateFlow<UserData> =
        userRepo.flow.stateIn(viewModelScope, SharingStarted.Eagerly, UserData())

    val settings: StateFlow<AppSettings> =
        settingsRepo.flow.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    val options = MutableStateFlow(ViewOptions())

    val folders: StateFlow<List<FolderInfo>> =
        media.map { ContentBuilder.folders(it) }.flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val albums: StateFlow<List<AlbumInfo>> =
        combine(media, userData) { list, ud ->
            val byId = list.associateBy { it.id }
            ud.albums.map { a ->
                val present = a.items.mapNotNull { byId[it] }
                AlbumInfo(a, present.size, present.maxByOrNull { it.dateMillis })
            }
        }.flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val contentFlows = HashMap<Source, StateFlow<Content>>()

    /** Contenido ya filtrado, ordenado y agrupado (calculado fuera del hilo principal). */
    fun content(source: Source): StateFlow<Content> = contentFlows.getOrPut(source) {
        val base = if (source == Source.Trash) trash else media
        combine(base, userData, options) { list, ud, opt -> ContentBuilder.build(list, ud, opt, source) }
            .flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), Content.Empty)
    }

    // --- Estado de interfaz compartido ---
    var selection by mutableStateOf<Set<Long>>(emptySet())
        private set
    var viewer by mutableStateOf<ViewerSession?>(null)

    init {
        // La ordenación predeterminada de Ajustes se aplica al cambiarla.
        viewModelScope.launch {
            settingsRepo.flow.map { it.defaultSort }.distinctUntilChanged().collect { s ->
                options.update { it.copy(sortField = s) }
            }
        }
    }

    fun onPermissionChanged() {
        refreshTick.tryEmit(Unit)
    }

    // --- Selección ---
    fun toggleSelect(id: Long) {
        selection = if (id in selection) selection - id else selection + id
    }

    fun selectAll(ids: Collection<Long>) {
        selection = ids.toSet()
    }

    fun clearSelection() {
        selection = emptySet()
    }

    // --- Búsqueda, filtros y orden ---
    fun setQuery(q: String) = options.update { it.copy(query = q) }
    fun setType(t: TypeFilter) = options.update { it.copy(type = t) }
    fun setDate(d: DateFilter) = options.update { it.copy(date = d) }
    fun setSort(f: SortField) = options.update { it.copy(sortField = f) }
    fun setDescending(v: Boolean) = options.update { it.copy(descending = v) }

    // --- Ajustes ---
    fun editSettings(block: suspend SettingsRepository.() -> Unit) {
        viewModelScope.launch { settingsRepo.block() }
    }

    // --- Favoritos y álbumes ---
    fun setFavorite(ids: Collection<Long>, favorite: Boolean) {
        viewModelScope.launch { userRepo.setFavorite(ids, favorite) }
    }

    fun createAlbum(name: String, ids: Collection<Long> = emptyList()) {
        if (name.isBlank()) return
        viewModelScope.launch { userRepo.createAlbum(name, ids) }
    }

    fun renameAlbum(id: String, name: String) {
        if (name.isBlank()) return
        viewModelScope.launch { userRepo.renameAlbum(id, name) }
    }

    fun deleteAlbum(id: String) {
        viewModelScope.launch { userRepo.deleteAlbum(id) }
    }

    fun addToAlbum(albumId: String, ids: Collection<Long>) {
        viewModelScope.launch { userRepo.addToAlbum(albumId, ids) }
    }

    fun removeFromAlbum(albumId: String, ids: Collection<Long>) {
        viewModelScope.launch { userRepo.removeFromAlbum(albumId, ids) }
    }

    // --- Archivos ---
    fun copyTo(items: List<MediaFile>, folder: String) {
        viewModelScope.launch {
            val n = MediaOps.copyTo(ctx, items, folder)
            toast(if (n == items.size) "Copiados $n archivos a «$folder»" else "Copiados $n de ${items.size} archivos")
        }
    }

    fun moveTo(items: List<MediaFile>, folder: String) {
        viewModelScope.launch {
            val n = MediaOps.moveTo(ctx, items, folder)
            toast(if (n == items.size) "Movidos $n archivos a «$folder»" else "Movidos $n de ${items.size} archivos")
            onPermissionChanged()
        }
    }

    fun toast(message: String) {
        Toast.makeText(ctx, message, Toast.LENGTH_SHORT).show()
    }
}
