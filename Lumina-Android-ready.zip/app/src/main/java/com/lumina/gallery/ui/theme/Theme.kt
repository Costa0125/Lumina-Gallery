package com.lumina.gallery.ui.theme

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import com.lumina.gallery.data.ThemeMode

// Identidad original: tinta casi negra con acento "lumen" ámbar.
private val DarkScheme = darkColorScheme(
    primary = Color(0xFFF2C27B),
    onPrimary = Color(0xFF2A1B00),
    primaryContainer = Color(0xFF4A3410),
    onPrimaryContainer = Color(0xFFFFDDA8),
    secondaryContainer = Color(0xFF2B2A31),
    onSecondaryContainer = Color(0xFFF2EEE6),
    background = Color(0xFF0C0D10),
    onBackground = Color(0xFFECEDEF),
    surface = Color(0xFF14161A),
    onSurface = Color(0xFFECEDEF),
    surfaceVariant = Color(0xFF1E2127),
    onSurfaceVariant = Color(0xFFB4B7BF),
    surfaceContainer = Color(0xFF17191E),
    surfaceContainerHigh = Color(0xFF1E2127),
    outline = Color(0xFF50535B),
    error = Color(0xFFFF8A80),
)

private val LightScheme = lightColorScheme(
    primary = Color(0xFF8A5B00),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFFFDDA8),
    onPrimaryContainer = Color(0xFF2A1B00),
    secondaryContainer = Color(0xFFE9E5DB),
    onSecondaryContainer = Color(0xFF1C1B17),
    background = Color(0xFFF6F5F2),
    onBackground = Color(0xFF1A1B1E),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF1A1B1E),
    surfaceVariant = Color(0xFFECEAE4),
    onSurfaceVariant = Color(0xFF55575E),
    surfaceContainer = Color(0xFFF0EEE9),
    surfaceContainerHigh = Color(0xFFE8E5DE),
    outline = Color(0xFF8B8D94),
    error = Color(0xFFB3261E),
)

private val LuminaShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp),
)

internal tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

@Composable
fun LuminaTheme(mode: ThemeMode, forceDark: Boolean = false, content: @Composable () -> Unit) {
    val dark = forceDark || when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val view = LocalView.current
    SideEffect {
        val window = view.context.findActivity()?.window ?: return@SideEffect
        val controller = WindowCompat.getInsetsController(window, view)
        controller.isAppearanceLightStatusBars = !dark
        controller.isAppearanceLightNavigationBars = !dark
    }
    MaterialTheme(
        colorScheme = if (dark) DarkScheme else LightScheme,
        shapes = LuminaShapes,
        content = content,
    )
}
