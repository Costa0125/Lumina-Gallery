package com.lumina.gallery

import android.app.Application
import coil3.ImageLoader
import coil3.PlatformContext
import coil3.SingletonImageLoader
import coil3.gif.AnimatedImageDecoder
import coil3.video.VideoFrameDecoder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class LuminaApp : Application(), SingletonImageLoader.Factory {

    /** Ámbito de la aplicación para escrituras que deben sobrevivir al cierre de una pantalla. */
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun newImageLoader(context: PlatformContext): ImageLoader =
        ImageLoader.Builder(context)
            .components {
                add(AnimatedImageDecoder.Factory()) // GIF animados en el visor
                add(VideoFrameDecoder.Factory())    // miniaturas de vídeo
            }
            .build()
}
