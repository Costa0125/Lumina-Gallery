package com.lumina.gallery.data

import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentSender
import android.net.Uri
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Operaciones sobre archivos usando solo los mecanismos oficiales de autorización de Android 11+. */
object MediaOps {

    fun trashRequest(resolver: ContentResolver, uris: List<Uri>, trash: Boolean): IntentSender =
        MediaStore.createTrashRequest(resolver, uris, trash).intentSender

    fun deleteRequest(resolver: ContentResolver, uris: List<Uri>): IntentSender =
        MediaStore.createDeleteRequest(resolver, uris).intentSender

    fun writeRequest(resolver: ContentResolver, uris: List<Uri>): IntentSender =
        MediaStore.createWriteRequest(resolver, uris).intentSender

    fun share(context: Context, items: List<MediaFile>) {
        if (items.isEmpty()) return
        val intent = if (items.size == 1) {
            Intent(Intent.ACTION_SEND)
                .setType(items[0].mime)
                .putExtra(Intent.EXTRA_STREAM, items[0].uri)
        } else {
            val type = when {
                items.all { it.isVideo } -> "video/*"
                items.none { it.isVideo } -> "image/*"
                else -> "*/*"
            }
            Intent(Intent.ACTION_SEND_MULTIPLE)
                .setType(type)
                .putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(items.map { it.uri }))
        }
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        context.startActivity(Intent.createChooser(intent, "Compartir"))
    }

    private fun relativePath(video: Boolean, folder: String): String {
        val clean = folder.trim().trim('/').replace("..", "")
        return if (video) "Movies/$clean/" else "Pictures/$clean/"
    }

    /** Copia los archivos a una carpeta (Pictures/<carpeta> o Movies/<carpeta>). No pide permisos extra. */
    suspend fun copyTo(context: Context, items: List<MediaFile>, folder: String): Int =
        withContext(Dispatchers.IO) {
            val resolver = context.contentResolver
            var copied = 0
            for (m in items) {
                var dest: Uri? = null
                try {
                    val collection = if (m.isVideo) {
                        MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                    } else {
                        MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                    }
                    val values = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, m.name)
                        put(MediaStore.MediaColumns.MIME_TYPE, m.mime)
                        put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath(m.isVideo, folder))
                        put(MediaStore.MediaColumns.IS_PENDING, 1)
                    }
                    dest = resolver.insert(collection, values) ?: continue
                    resolver.openInputStream(m.uri)!!.use { input ->
                        resolver.openOutputStream(dest)!!.use { output -> input.copyTo(output, 256 * 1024) }
                    }
                    resolver.update(
                        dest,
                        ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) },
                        null,
                        null,
                    )
                    copied++
                } catch (_: Exception) {
                    dest?.let { runCatching { resolver.delete(it, null, null) } }
                }
            }
            copied
        }

    /** Mueve cambiando RELATIVE_PATH. Requiere haber obtenido antes la autorización de escritura. */
    suspend fun moveTo(context: Context, items: List<MediaFile>, folder: String): Int =
        withContext(Dispatchers.IO) {
            var moved = 0
            for (m in items) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath(m.isVideo, folder))
                }
                val rows = runCatching { context.contentResolver.update(m.uri, values, null, null) }
                    .getOrDefault(0)
                if (rows > 0) moved++
            }
            moved
        }
}
