package com.lumina.gallery.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.RotateRight
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Slideshow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil3.compose.AsyncImage
import coil3.compose.LocalPlatformContext
import coil3.request.ImageRequest
import com.lumina.gallery.data.MediaFile
import com.lumina.gallery.data.formatDate
import com.lumina.gallery.data.formatSize
import com.lumina.gallery.ui.theme.findActivity
import kotlinx.coroutines.delay
import kotlin.math.min

/** Visor de fotos: deslizar entre fotos, zoom con dos dedos, rotación visual, presentación y acciones. */
@Composable
fun PhotoViewer(vm: MainViewModel, session: ViewerSession, onClose: () -> Unit) {
    val media by vm.media.collectAsStateWithLifecycle()
    val userData by vm.userData.collectAsStateWithLifecycle()
    val actions = rememberMediaActions(vm)

    val items = remember(session, media) {
        val byId = media.associateBy { it.id }
        session.ids.mapNotNull { byId[it] }
    }
    BackHandler(onBack = onClose)

    // Barras de estado con iconos claros sobre el fondo negro; se restauran al salir.
    val view = LocalView.current
    DisposableEffect(Unit) {
        val window = view.context.findActivity()?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, view) }
        val previous = controller?.isAppearanceLightStatusBars
        controller?.isAppearanceLightStatusBars = false
        onDispose { if (controller != null && previous != null) controller.isAppearanceLightStatusBars = previous }
    }

    if (items.isEmpty()) {
        LaunchedEffect(Unit) { onClose() }
        Box(Modifier.fillMaxSize().background(Color.Black))
        return
    }

    val pagerState = rememberPagerState(initialPage = session.startIndex.coerceIn(0, items.lastIndex)) { items.size }
    var chrome by remember { mutableStateOf(true) }
    var zoomed by remember { mutableStateOf(false) }
    var slideshow by remember { mutableStateOf(false) }
    var showInfo by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val rotations = remember { mutableStateMapOf<Long, Int>() }

    val current = items[pagerState.currentPage.coerceIn(0, items.lastIndex)]
    val isFav = current.id in userData.favorites

    LaunchedEffect(slideshow, pagerState.currentPage, items.size) {
        if (slideshow) {
            chrome = false
            delay(3_000)
            pagerState.animateScrollToPage((pagerState.currentPage + 1) % items.size)
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        HorizontalPager(
            state = pagerState,
            userScrollEnabled = !zoomed,
            key = { items.getOrNull(it)?.id ?: it },
            beyondViewportPageCount = 1,
            modifier = Modifier.fillMaxSize(),
        ) { page ->
            val file = items[page.coerceIn(0, items.lastIndex)]
            ZoomableImage(
                file = file,
                rotation = rotations[file.id] ?: 0,
                onTap = { chrome = !chrome; if (slideshow) slideshow = false },
                onZoomChanged = { z -> if (page == pagerState.currentPage) zoomed = z },
            )
        }

        AnimatedVisibility(
            visible = chrome,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.TopCenter),
        ) {
            Row(
                Modifier.fillMaxWidth().height(110.dp)
                    .background(Brush.verticalGradient(listOf(Color(0xCC000000), Color.Transparent)))
                    .statusBarsPadding().padding(horizontal = 4.dp),
                verticalAlignment = Alignment.Top,
            ) {
                IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Volver", tint = Color.White) }
                Column(Modifier.weight(1f).padding(top = 8.dp)) {
                    Text(current.name, color = Color.White, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        "${formatDate(current.dateMillis)}  ·  ${pagerState.currentPage + 1}/${items.size}",
                        color = Color(0xCCFFFFFF),
                        fontSize = 12.sp,
                    )
                }
            }
        }

        AnimatedVisibility(
            visible = chrome,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter),
        ) {
            Row(
                Modifier.fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xE6000000))))
                    .navigationBarsPadding().padding(top = 28.dp, bottom = 6.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
            ) {
                IconButton(onClick = { actions.share(listOf(current)) }) { Icon(Icons.Rounded.Share, "Compartir", tint = Color.White) }
                IconButton(onClick = { vm.setFavorite(listOf(current.id), !isFav) }) {
                    Icon(
                        if (isFav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        if (isFav) "Quitar de favoritos" else "Añadir a favoritos",
                        tint = Color.White,
                    )
                }
                IconButton(onClick = { rotations[current.id] = ((rotations[current.id] ?: 0) + 90) % 360 }) {
                    Icon(Icons.Rounded.RotateRight, "Rotar", tint = Color.White)
                }
                IconButton(onClick = { showInfo = true }) { Icon(Icons.Rounded.Info, "Información", tint = Color.White) }
                IconButton(onClick = { slideshow = !slideshow }) {
                    Icon(
                        if (slideshow) Icons.Rounded.Pause else Icons.Rounded.Slideshow,
                        if (slideshow) "Detener presentación" else "Presentación",
                        tint = Color.White,
                    )
                }
                IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Rounded.Delete, "Eliminar", tint = Color.White) }
            }
        }
    }

    if (showInfo) {
        AlertDialog(
            onDismissRequest = { showInfo = false },
            confirmButton = { TextButton(onClick = { showInfo = false }) { Text("Cerrar") } },
            title = { Text("Información") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(current.name)
                    Text("Resolución: ${current.width} × ${current.height}")
                    Text("Tamaño: ${formatSize(current.size)}")
                    Text("Fecha: ${formatDate(current.dateMillis)}")
                    Text("Carpeta: ${current.relativePath.ifBlank { current.bucketName }}")
                    Text("Tipo: ${current.mime}")
                }
            },
        )
    }
    if (confirmDelete) {
        ConfirmDialog(
            title = "¿Enviar a la papelera?",
            text = "Podrás recuperarla desde la papelera durante unos 30 días.",
            confirmLabel = "Enviar a la papelera",
            destructive = true,
            onConfirm = { actions.trash(listOf(current)) },
            onDismiss = { confirmDelete = false },
        )
    }
}

@Composable
private fun ZoomableImage(
    file: MediaFile,
    rotation: Int,
    onTap: () -> Unit,
    onZoomChanged: (Boolean) -> Unit,
) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    var intrinsic by remember { mutableStateOf(Size.Unspecified) }
    val context = LocalPlatformContext.current
    // Resolución alta decodificada fuera del hilo principal por Coil, con tope para no agotar la memoria.
    val request = remember(file.id) { ImageRequest.Builder(context).data(file.uri).size(2400, 2400).build() }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val w = constraints.maxWidth.toFloat()
        val h = constraints.maxHeight.toFloat()
        // Al girar 90° la imagen debe volver a ajustarse a la pantalla sin recortarse.
        val fit = if (rotation % 180 != 0 && intrinsic != Size.Unspecified && intrinsic.width > 0f && intrinsic.height > 0f) {
            min(w / intrinsic.height, h / intrinsic.width) / min(w / intrinsic.width, h / intrinsic.height)
        } else {
            1f
        }
        AsyncImage(
            model = request,
            contentDescription = file.name,
            contentScale = ContentScale.Fit,
            onSuccess = { s -> intrinsic = s.painter.intrinsicSize },
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = { onTap() },
                        onDoubleTap = {
                            if (scale > 1f) {
                                scale = 1f
                                offset = Offset.Zero
                            } else {
                                scale = 2.5f
                            }
                            onZoomChanged(scale > 1f)
                        },
                    )
                }
                .pointerInput(Unit) {
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false)
                        do {
                            val event = awaitPointerEvent()
                            val multiTouch = event.changes.count { it.pressed } >= 2
                            // Con un dedo y sin zoom no se consume nada: así el deslizamiento entre fotos sigue funcionando.
                            if (multiTouch || scale > 1f) {
                                val z = event.calculateZoom()
                                val p = event.calculatePan()
                                val newScale = (scale * z).coerceIn(1f, 6f)
                                scale = newScale
                                val maxX = size.width * (newScale - 1f) / 2f
                                val maxY = size.height * (newScale - 1f) / 2f
                                offset = if (newScale <= 1f) {
                                    Offset.Zero
                                } else {
                                    Offset(
                                        (offset.x + p.x).coerceIn(-maxX, maxX),
                                        (offset.y + p.y).coerceIn(-maxY, maxY),
                                    )
                                }
                                event.changes.forEach { if (it.positionChanged()) it.consume() }
                                onZoomChanged(scale > 1f)
                            }
                        } while (event.changes.any { it.pressed })
                    }
                }
                .graphicsLayer {
                    scaleX = scale * fit
                    scaleY = scale * fit
                    translationX = offset.x
                    translationY = offset.y
                    rotationZ = rotation.toFloat()
                },
        )
    }
}
