package com.lumina.gallery.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

val Context.luminaStore: DataStore<Preferences> by preferencesDataStore(name = "lumina")

private object K {
    val THEME = stringPreferencesKey("theme")
    val HIDE = intPreferencesKey("hide_seconds")
    val SPEED = floatPreferencesKey("default_speed")
    val GESTURES = booleanPreferencesKey("gestures")
    val CENTER_TAP = booleanPreferencesKey("center_tap")
    val SEEK = intPreferencesKey("seek_seconds")
    val FRAME = stringPreferencesKey("frame_mode")
    val RESUME = booleanPreferencesKey("resume")
    val THUMB = stringPreferencesKey("thumb_size")
    val SORT = stringPreferencesKey("default_sort")
    val HAPTICS = booleanPreferencesKey("haptics")

    val FAV = stringSetPreferencesKey("favorites")
    val ALBUMS = stringSetPreferencesKey("album_ids")
    fun albumName(id: String) = stringPreferencesKey("album_name_$id")
    fun albumItems(id: String) = stringSetPreferencesKey("album_items_$id")
    fun pos(key: String) = stringPreferencesKey("pos_$key")
}

private inline fun <reified E : Enum<E>> String?.toEnum(default: E): E =
    if (this == null) default else runCatching { enumValueOf<E>(this) }.getOrDefault(default)

class SettingsRepository(private val context: Context) {

    val flow: Flow<AppSettings> = context.luminaStore.data.map { p ->
        AppSettings(
            themeMode = p[K.THEME].toEnum(ThemeMode.SYSTEM),
            hideSeconds = p[K.HIDE] ?: 4,
            defaultSpeed = p[K.SPEED] ?: 1f,
            gestures = p[K.GESTURES] ?: true,
            doubleTapCenterPause = p[K.CENTER_TAP] ?: false,
            seekSeconds = p[K.SEEK] ?: 10,
            frameMode = p[K.FRAME].toEnum(FrameMode.FIT).let { if (it == FrameMode.ZOOM) FrameMode.FIT else it },
            resume = p[K.RESUME] ?: true,
            thumbSize = p[K.THUMB].toEnum(ThumbSize.MEDIUM),
            defaultSort = p[K.SORT].toEnum(SortField.DATE),
            haptics = p[K.HAPTICS] ?: true,
        )
    }

    suspend fun setTheme(v: ThemeMode) = edit { it[K.THEME] = v.name }
    suspend fun setHideSeconds(v: Int) = edit { it[K.HIDE] = v }
    suspend fun setDefaultSpeed(v: Float) = edit { it[K.SPEED] = v }
    suspend fun setGestures(v: Boolean) = edit { it[K.GESTURES] = v }
    suspend fun setCenterTap(v: Boolean) = edit { it[K.CENTER_TAP] = v }
    suspend fun setSeekSeconds(v: Int) = edit { it[K.SEEK] = v }
    suspend fun setFrameMode(v: FrameMode) = edit { it[K.FRAME] = v.name }
    suspend fun setResume(v: Boolean) = edit { it[K.RESUME] = v }
    suspend fun setThumbSize(v: ThumbSize) = edit { it[K.THUMB] = v.name }
    suspend fun setDefaultSort(v: SortField) = edit { it[K.SORT] = v.name }
    suspend fun setHaptics(v: Boolean) = edit { it[K.HAPTICS] = v }

    private suspend fun edit(block: (androidx.datastore.preferences.core.MutablePreferences) -> Unit) {
        context.luminaStore.edit { block(it) }
    }
}

/** Favoritos, álbumes propios y posiciones de reproducción. Todo local, nada sale del teléfono. */
class UserDataRepository(private val context: Context) {

    val flow: Flow<UserData> = context.luminaStore.data.map { p ->
        val favs = p[K.FAV].orEmpty().mapNotNull { it.toLongOrNull() }.toSet()
        val albums = p[K.ALBUMS].orEmpty().map { id ->
            UserAlbum(
                id = id,
                name = p[K.albumName(id)] ?: "Álbum",
                items = p[K.albumItems(id)].orEmpty().mapNotNull { it.toLongOrNull() }.toSet(),
            )
        }.sortedBy { it.name.lowercase() }
        val positions = HashMap<String, PlaybackPos>()
        for ((key, value) in p.asMap()) {
            if (key.name.startsWith("pos_") && value is String) {
                parsePos(value)?.let { positions[key.name.removePrefix("pos_")] = it }
            }
        }
        UserData(favs, albums, positions)
    }

    suspend fun setFavorite(ids: Collection<Long>, favorite: Boolean) {
        context.luminaStore.edit { p ->
            val cur = p[K.FAV].orEmpty().toMutableSet()
            val strs = ids.map { it.toString() }
            if (favorite) cur.addAll(strs) else cur.removeAll(strs.toSet())
            p[K.FAV] = cur
        }
    }

    suspend fun createAlbum(name: String, ids: Collection<Long> = emptyList()): String {
        val id = System.currentTimeMillis().toString()
        context.luminaStore.edit { p ->
            p[K.ALBUMS] = p[K.ALBUMS].orEmpty() + id
            p[K.albumName(id)] = name.trim()
            p[K.albumItems(id)] = ids.map { it.toString() }.toSet()
        }
        return id
    }

    suspend fun renameAlbum(id: String, name: String) {
        context.luminaStore.edit { it[K.albumName(id)] = name.trim() }
    }

    /** Borra solo la lista del álbum; los archivos originales no se tocan. */
    suspend fun deleteAlbum(id: String) {
        context.luminaStore.edit { p ->
            p[K.ALBUMS] = p[K.ALBUMS].orEmpty() - id
            p.remove(K.albumName(id))
            p.remove(K.albumItems(id))
        }
    }

    suspend fun addToAlbum(albumId: String, ids: Collection<Long>) {
        context.luminaStore.edit { p ->
            p[K.albumItems(albumId)] = p[K.albumItems(albumId)].orEmpty() + ids.map { it.toString() }
        }
    }

    suspend fun removeFromAlbum(albumId: String, ids: Collection<Long>) {
        context.luminaStore.edit { p ->
            p[K.albumItems(albumId)] = p[K.albumItems(albumId)].orEmpty() - ids.map { it.toString() }.toSet()
        }
    }

    suspend fun savePosition(key: String, positionMs: Long, durationMs: Long) {
        context.luminaStore.edit { it[K.pos(key)] = "$positionMs|$durationMs|${System.currentTimeMillis()}" }
    }

    suspend fun clearPosition(key: String) {
        context.luminaStore.edit { it.remove(K.pos(key)) }
    }

    suspend fun getPosition(key: String): PlaybackPos? =
        context.luminaStore.data.first()[K.pos(key)]?.let(::parsePos)

    private fun parsePos(raw: String): PlaybackPos? {
        val parts = raw.split('|')
        if (parts.size < 3) return null
        return PlaybackPos(
            positionMs = parts[0].toLongOrNull() ?: return null,
            durationMs = parts[1].toLongOrNull() ?: return null,
            updatedAt = parts[2].toLongOrNull() ?: 0L,
        )
    }
}
