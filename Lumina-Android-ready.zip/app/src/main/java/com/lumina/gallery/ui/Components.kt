package com.lumina.gallery.ui

import android.app.Activity
import android.content.Context
import android.content.IntentSender
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.ActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import coil3.compose.LocalPlatformContext
import coil3.request.ImageRequest
import coil3.request.crossfade
import coil3.video.videoFrameMillis
import com.lumina.gallery.data.MediaFile
import com.lumina.gallery.data.MediaOps
import com.lumina.gallery.data.UserAlbum
import com.lumina.gallery.data.formatTime

/** Miniatura (foto o fotograma de vídeo) decodificada al tamaño pedido, fuera del hilo principal. */
@Composable
fun Thumb(file: MediaFile, px: Int, modifier: Modifier = Modifier, contentScale: ContentScale = ContentScale.Crop) {
    val context = LocalPlatformContext.current
    val request = remember(file.id, px) {
        ImageRequest.Builder(context)
            .data(file.uri)
            .size(px, px)
            .apply { if (file.isVideo) videoFrameMillis(1_000) }
            .crossfade(true)
            .build()
    }
    AsyncImage(model = request, contentDescription = file.name, contentScale = contentScale, modifier = modifier)
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MediaCell(
    file: MediaFile,
    thumbPx: Int,
    selected: Boolean,
    selecting: Boolean,
    favorite: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
) {
    val scale by animateFloatAsState(if (selected) 0.86f else 1f, label = "cellScale")
    Box(
        Modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(6.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick),
    ) {
        Thumb(
            file, thumbPx,
            Modifier.fillMaxSize().graphicsLayer {
                scaleX = scale
                scaleY = scale
            },
        )
        if (file.isVideo) {
            Row(
                Modifier.align(Alignment.BottomEnd).padding(4.dp).clip(RoundedCornerShape(10.dp))
                    .background(Color(0x99000000)).padding(horizontal = 5.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Rounded.PlayArrow, null, tint = Color.White, modifier = Modifier.size(13.dp))
                Text(formatTime(file.durationMs), color = Color.White, fontSize = 11.sp)
            }
        }
        if (favorite && !selecting) {
            Icon(
                Icons.Rounded.Favorite, "Favorito", tint = Color.White,
                modifier = Modifier.align(Alignment.BottomStart).padding(5.dp).size(15.dp),
            )
        }
        if (selecting) {
            Box(
                Modifier.align(Alignment.TopStart).padding(6.dp).size(22.dp).clip(CircleShape)
                    .background(if (selected) MaterialTheme.colorScheme.primary else Color(0x66000000))
                    .border(1.5.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                if (selected) {
                    Icon(Icons.Rounded.Check, null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(14.dp))
                }
            }
        }
    }
}

@Composable
fun SectionHeader(title: String, modifier: Modifier = Modifier) {
    Text(
        title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.SemiBold,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = modifier.fillMaxWidth().padding(start = 4.dp, end = 4.dp, top = 18.dp, bottom = 6.dp),
    )
}

// ------------------------------------------------------------------------------------------
// Diálogos
// ------------------------------------------------------------------------------------------

@Composable
fun ConfirmDialog(
    title: String,
    text: String,
    confirmLabel: String,
    destructive: Boolean = false,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = {
            TextButton(onClick = { onConfirm(); onDismiss() }) {
                Text(
                    confirmLabel,
                    color = if (destructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                )
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}

@Composable
fun TextInputDialog(
    title: String,
    label: String,
    initial: String = "",
    confirmLabel: String = "Aceptar",
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var value by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = value,
                onValueChange = { value = it.take(60) },
                label = { Text(label) },
                singleLine = true,
            )
        },
        confirmButton = {
            TextButton(
                enabled = value.isNotBlank(),
                onClick = { onConfirm(value.trim()); onDismiss() },
            ) { Text(confirmLabel) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}

@Composable
fun AlbumPickerDialog(
    albums: List<UserAlbum>,
    onPick: (UserAlbum) -> Unit,
    onNew: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var creating by remember { mutableStateOf(false) }
    if (creating) {
        TextInputDialog(
            title = "Nuevo álbum",
            label = "Nombre",
            confirmLabel = "Crear y añadir",
            onConfirm = onNew,
            onDismiss = onDismiss,
        )
        return
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Añadir a un álbum") },
        text = {
            LazyColumn(Modifier.heightIn(max = 320.dp)) {
                item {
                    Row(
                        Modifier.fillMaxWidth().clickable { creating = true }.padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Icon(Icons.Rounded.Add, null, tint = MaterialTheme.colorScheme.primary)
                        Text("Nuevo álbum…", color = MaterialTheme.colorScheme.primary)
                    }
                }
                items(albums, key = { it.id }) { a ->
                    Text(
                        a.name,
                        modifier = Modifier.fillMaxWidth().clickable { onPick(a); onDismiss() }.padding(vertical = 12.dp),
                    )
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}

// ------------------------------------------------------------------------------------------
// Operaciones sobre archivos con autorización oficial del sistema (papelera, borrado, escritura)
// ------------------------------------------------------------------------------------------

class MediaActions internal constructor(
    private val context: Context,
    private val vm: MainViewModel,
    private val launch: (IntentSender, () -> Unit) -> Unit,
) {
    private val resolver get() = context.contentResolver

    /** Envía a la papelera del sistema (recuperable durante unos 30 días). */
    fun trash(items: List<MediaFile>, onDone: () -> Unit = {}) {
        if (items.isEmpty()) return
        launch(MediaOps.trashRequest(resolver, items.map { it.uri }, true)) {
            vm.toast(if (items.size == 1) "Enviado a la papelera" else "${items.size} elementos enviados a la papelera")
            vm.clearSelection()
            onDone()
        }
    }

    fun restore(items: List<MediaFile>) {
        if (items.isEmpty()) return
        launch(MediaOps.trashRequest(resolver, items.map { it.uri }, false)) {
            vm.toast(if (items.size == 1) "Elemento restaurado" else "${items.size} elementos restaurados")
            vm.clearSelection()
        }
    }

    fun deletePermanently(items: List<MediaFile>) {
        if (items.isEmpty()) return
        launch(MediaOps.deleteRequest(resolver, items.map { it.uri })) {
            vm.toast("Eliminado definitivamente")
            vm.clearSelection()
        }
    }

    fun move(items: List<MediaFile>, folder: String) {
        if (items.isEmpty()) return
        launch(MediaOps.writeRequest(resolver, items.map { it.uri })) {
            vm.moveTo(items, folder)
            vm.clearSelection()
        }
    }

    fun share(items: List<MediaFile>) = MediaOps.share(context, items)
}

@Composable
fun rememberMediaActions(vm: MainViewModel): MediaActions {
    val context = LocalContext.current
    var pending by remember { mutableStateOf<(() -> Unit)?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r: ActivityResult ->
        if (r.resultCode == Activity.RESULT_OK) pending?.invoke()
        pending = null
    }
    return remember(context, vm) {
        MediaActions(context, vm) { sender, onOk ->
            pending = onOk
            launcher.launch(IntentSenderRequest.Builder(sender).build())
        }
    }
}
