package com.lumina.gallery.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.PhotoAlbum
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.lumina.gallery.data.AlbumInfo
import com.lumina.gallery.data.MediaFile
import com.lumina.gallery.data.Source

private sealed interface AlbumDialog {
    data object Create : AlbumDialog
    data class Rename(val info: AlbumInfo) : AlbumDialog
    data class Delete(val info: AlbumInfo) : AlbumDialog
}

@Composable
fun AlbumsScreen(
    vm: MainViewModel,
    gridState: LazyGridState,
    onOpenSource: (Source) -> Unit,
    onOpenSettings: () -> Unit,
    onOpenTrash: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val albums by vm.albums.collectAsStateWithLifecycle()
    val folders by vm.folders.collectAsStateWithLifecycle()
    var dialog by remember { mutableStateOf<AlbumDialog?>(null) }

    Column(modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 8.dp).height(64.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "Álbumes",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f).padding(start = 8.dp),
            )
            IconButton(onClick = { dialog = AlbumDialog.Create }) { Icon(Icons.Rounded.Add, "Nuevo álbum") }
            IconButton(onClick = onOpenTrash) { Icon(Icons.Rounded.Delete, "Papelera") }
            IconButton(onClick = onOpenSettings) { Icon(Icons.Rounded.Settings, "Ajustes") }
        }

        LazyVerticalGrid(
            columns = GridCells.Adaptive(150.dp),
            state = gridState,
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            item(key = "h_mine", span = { GridItemSpan(maxLineSpan) }) { SectionHeader("Mis álbumes") }
            if (albums.isEmpty()) {
                item(key = "empty_mine", span = { GridItemSpan(maxLineSpan) }) {
                    Text(
                        "Crea un álbum con el botón + o selecciona fotos y elige «Añadir a álbum». " +
                            "Los álbumes solo agrupan: no duplican ni mueven tus archivos.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(horizontal = 4.dp),
                    )
                }
            }
            items(albums, key = { "a_${it.album.id}" }) { info ->
                var menu by remember { mutableStateOf(false) }
                Box {
                    CollectionCard(
                        title = info.album.name,
                        count = info.count,
                        cover = info.cover,
                        onClick = { onOpenSource(Source.Album(info.album.id, info.album.name)) },
                        onLongClick = { menu = true },
                    )
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(
                            text = { Text("Cambiar nombre") },
                            leadingIcon = { Icon(Icons.Rounded.Edit, null) },
                            onClick = { menu = false; dialog = AlbumDialog.Rename(info) },
                        )
                        DropdownMenuItem(
                            text = { Text("Eliminar álbum") },
                            leadingIcon = { Icon(Icons.Rounded.Delete, null) },
                            onClick = { menu = false; dialog = AlbumDialog.Delete(info) },
                        )
                    }
                }
            }

            item(key = "h_folders", span = { GridItemSpan(maxLineSpan) }) { SectionHeader("Carpetas del dispositivo") }
            items(folders, key = { "f_${it.bucketId}" }) { f ->
                CollectionCard(
                    title = f.name,
                    count = f.count,
                    cover = f.cover,
                    onClick = { onOpenSource(Source.Folder(f.bucketId, f.name)) },
                    onLongClick = null,
                )
            }
        }
    }

    when (val d = dialog) {
        AlbumDialog.Create -> TextInputDialog(
            title = "Nuevo álbum",
            label = "Nombre",
            confirmLabel = "Crear",
            onConfirm = { vm.createAlbum(it) },
            onDismiss = { dialog = null },
        )
        is AlbumDialog.Rename -> TextInputDialog(
            title = "Cambiar nombre",
            label = "Nombre",
            initial = d.info.album.name,
            onConfirm = { vm.renameAlbum(d.info.album.id, it) },
            onDismiss = { dialog = null },
        )
        is AlbumDialog.Delete -> ConfirmDialog(
            title = "¿Eliminar el álbum «${d.info.album.name}»?",
            text = "Solo se elimina el álbum. Las fotos y los vídeos originales NO se borran.",
            confirmLabel = "Eliminar álbum",
            destructive = true,
            onConfirm = { vm.deleteAlbum(d.info.album.id) },
            onDismiss = { dialog = null },
        )
        null -> Unit
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun CollectionCard(
    title: String,
    count: Int,
    cover: MediaFile?,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)?,
) {
    Column(
        Modifier.combinedClickable(onClick = onClick, onLongClick = onLongClick),
    ) {
        Box(
            Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(20.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center,
        ) {
            if (cover != null) {
                Thumb(cover, 420, Modifier.fillMaxSize())
            } else {
                Icon(
                    if (onLongClick != null) Icons.Rounded.PhotoAlbum else Icons.Rounded.Folder,
                    null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(40.dp),
                )
            }
        }
        Text(
            title,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(start = 4.dp, top = 6.dp),
        )
        Text(
            "$count",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(start = 4.dp),
        )
    }
}
