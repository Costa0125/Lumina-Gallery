package com.lumina.gallery.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.DriveFileMove
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.FilterList
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SelectAll
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.lumina.gallery.data.DateFilter
import com.lumina.gallery.data.MediaFile
import com.lumina.gallery.data.PlaybackPos
import com.lumina.gallery.data.SortField
import com.lumina.gallery.data.Source
import com.lumina.gallery.data.ThumbSize
import com.lumina.gallery.data.TypeFilter
import com.lumina.gallery.data.formatTime

private sealed interface GridDialog {
    data class Delete(val items: List<MediaFile>) : GridDialog
    data class DeleteForever(val items: List<MediaFile>) : GridDialog
    data class AddToAlbum(val ids: List<Long>) : GridDialog
    data class Copy(val items: List<MediaFile>) : GridDialog
    data class Move(val items: List<MediaFile>) : GridDialog
    data object Filters : GridDialog
}

/**
 * Pantalla de cuadrícula reutilizable: Fotos, Vídeos, Favoritos, carpetas, álbumes propios y papelera.
 * El [gridState] lo aporta quien la llama para conservar la posición de desplazamiento.
 */
@Composable
fun MediaGridScreen(
    vm: MainViewModel,
    source: Source,
    title: String,
    gridState: LazyGridState,
    onOpen: (file: MediaFile, list: List<MediaFile>) -> Unit,
    modifier: Modifier = Modifier,
    onBack: (() -> Unit)? = null,
    onOpenSettings: (() -> Unit)? = null,
    onOpenTrash: (() -> Unit)? = null,
    header: (@Composable () -> Unit)? = null,
    extraMenu: (@Composable (dismiss: () -> Unit) -> Unit)? = null,
    bottomPadding: Dp = 24.dp,
) {
    val content by vm.content(source).collectAsStateWithLifecycle()
    val userData by vm.userData.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val options by vm.options.collectAsStateWithLifecycle()
    val albums = userData.albums
    val selection = vm.selection
    val selecting = selection.isNotEmpty()
    val isTrash = source == Source.Trash
    val actions = rememberMediaActions(vm)

    var searching by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf<GridDialog?>(null) }

    val selectedFiles = remember(content, selection) { content.items.filter { it.id in selection } }

    DisposableEffect(Unit) {
        onDispose {
            vm.clearSelection()
            vm.setQuery("")
        }
    }
    BackHandler(enabled = searching && !selecting) {
        searching = false
        vm.setQuery("")
    }
    BackHandler(enabled = selecting) { vm.clearSelection() }

    Column(modifier.fillMaxSize()) {
        // ---------- Barra superior ----------
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 8.dp).height(64.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            when {
                selecting -> {
                    IconButton(onClick = { vm.clearSelection() }) { Icon(Icons.Rounded.Close, "Cancelar selección") }
                    Text(
                        "${selection.size} seleccionados",
                        style = MaterialTheme.typography.titleLarge,
                        modifier = Modifier.weight(1f).padding(start = 4.dp),
                    )
                    if (isTrash) {
                        IconButton(onClick = { actions.restore(selectedFiles) }) { Icon(Icons.Rounded.Restore, "Restaurar") }
                        IconButton(onClick = { dialog = GridDialog.DeleteForever(selectedFiles) }) {
                            Icon(Icons.Rounded.DeleteForever, "Eliminar definitivamente")
                        }
                        IconButton(onClick = { vm.selectAll(content.items.map { it.id }) }) {
                            Icon(Icons.Rounded.SelectAll, "Seleccionar todo")
                        }
                    } else {
                        val allFav = selectedFiles.isNotEmpty() && selectedFiles.all { it.id in userData.favorites }
                        IconButton(onClick = { actions.share(selectedFiles) }) { Icon(Icons.Rounded.Share, "Compartir") }
                        IconButton(onClick = { vm.setFavorite(selection, !allFav) }) {
                            Icon(if (allFav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, "Favorito")
                        }
                        IconButton(onClick = { dialog = GridDialog.Delete(selectedFiles) }) {
                            Icon(Icons.Rounded.Delete, "Eliminar")
                        }
                        Box {
                            IconButton(onClick = { menuOpen = true }) { Icon(Icons.Rounded.MoreVert, "Más") }
                            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                DropdownMenuItem(
                                    text = { Text("Seleccionar todo") },
                                    leadingIcon = { Icon(Icons.Rounded.SelectAll, null) },
                                    onClick = { menuOpen = false; vm.selectAll(content.items.map { it.id }) },
                                )
                                DropdownMenuItem(
                                    text = { Text("Añadir a álbum") },
                                    leadingIcon = { Icon(Icons.Rounded.CreateNewFolder, null) },
                                    onClick = { menuOpen = false; dialog = GridDialog.AddToAlbum(selection.toList()) },
                                )
                                if (source is Source.Album) {
                                    DropdownMenuItem(
                                        text = { Text("Quitar de este álbum") },
                                        leadingIcon = { Icon(Icons.Rounded.Close, null) },
                                        onClick = {
                                            menuOpen = false
                                            vm.removeFromAlbum(source.id, selection)
                                            vm.clearSelection()
                                        },
                                    )
                                }
                                DropdownMenuItem(
                                    text = { Text("Copiar a carpeta…") },
                                    leadingIcon = { Icon(Icons.Rounded.ContentCopy, null) },
                                    onClick = { menuOpen = false; dialog = GridDialog.Copy(selectedFiles) },
                                )
                                DropdownMenuItem(
                                    text = { Text("Mover a carpeta…") },
                                    leadingIcon = { Icon(Icons.Rounded.DriveFileMove, null) },
                                    onClick = { menuOpen = false; dialog = GridDialog.Move(selectedFiles) },
                                )
                            }
                        }
                    }
                }

                searching -> {
                    val focus = remember { FocusRequester() }
                    LaunchedEffect(Unit) { focus.requestFocus() }
                    IconButton(onClick = { searching = false; vm.setQuery("") }) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Cerrar búsqueda")
                    }
                    OutlinedTextField(
                        value = options.query,
                        onValueChange = vm::setQuery,
                        placeholder = { Text("Buscar por nombre") },
                        singleLine = true,
                        shape = RoundedCornerShape(28.dp),
                        modifier = Modifier.weight(1f).focusRequester(focus),
                    )
                    IconButton(onClick = { dialog = GridDialog.Filters }) { Icon(Icons.Rounded.FilterList, "Filtros") }
                }

                else -> {
                    if (onBack != null) {
                        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Volver") }
                    }
                    Column(Modifier.weight(1f).padding(start = if (onBack != null) 0.dp else 8.dp)) {
                        Text(
                            title,
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            "${content.items.size} elementos",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    IconButton(onClick = { searching = true }) { Icon(Icons.Rounded.Search, "Buscar") }
                    IconButton(onClick = { dialog = GridDialog.Filters }) { Icon(Icons.Rounded.FilterList, "Filtros y orden") }
                    Box {
                        IconButton(onClick = { menuOpen = true }) { Icon(Icons.Rounded.MoreVert, "Más") }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(
                                text = { Text("Seleccionar") },
                                leadingIcon = { Icon(Icons.Rounded.SelectAll, null) },
                                onClick = { menuOpen = false; vm.selectAll(content.items.map { it.id }) },
                            )
                            if (onOpenTrash != null) {
                                DropdownMenuItem(
                                    text = { Text("Papelera") },
                                    leadingIcon = { Icon(Icons.Rounded.Delete, null) },
                                    onClick = { menuOpen = false; onOpenTrash() },
                                )
                            }
                            if (onOpenSettings != null) {
                                DropdownMenuItem(
                                    text = { Text("Ajustes") },
                                    leadingIcon = { Icon(Icons.Rounded.Settings, null) },
                                    onClick = { menuOpen = false; onOpenSettings() },
                                )
                            }
                            extraMenu?.invoke { menuOpen = false }
                        }
                    }
                }
            }
        }

        // ---------- Chips de tipo ----------
        if (source != Source.Videos && !selecting) {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                TypeFilter.entries.forEach { t ->
                    FilterChip(
                        selected = options.type == t,
                        onClick = { vm.setType(t) },
                        label = { Text(t.label) },
                    )
                }
            }
        }

        // ---------- Cuadrícula ----------
        if (content.items.isEmpty() && header == null) {
            Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                Text(
                    when {
                        options.query.isNotBlank() -> "Sin resultados para «${options.query}»"
                        isTrash -> "La papelera está vacía"
                        source == Source.Favorites -> "Aún no hay favoritos. Toca el corazón en una foto o vídeo."
                        else -> "No hay elementos para mostrar"
                    },
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        } else {
            val thumbPx = settings.thumbSize.requestPx
            LazyVerticalGrid(
                columns = GridCells.Adaptive(settings.thumbSize.minDp.dp),
                state = gridState,
                contentPadding = PaddingValues(start = 4.dp, end = 4.dp, bottom = bottomPadding),
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                if (header != null) {
                    item(key = "header", span = { GridItemSpan(maxLineSpan) }, contentType = "header") { header() }
                }
                content.sections.forEach { section ->
                    if (section.title.isNotBlank()) {
                        item(key = "h_${section.title}", span = { GridItemSpan(maxLineSpan) }, contentType = "title") {
                            SectionHeader(section.title)
                        }
                    }
                    items(section.items, key = { it.id }, contentType = { "cell" }) { f ->
                        MediaCell(
                            file = f,
                            thumbPx = thumbPx,
                            selected = f.id in selection,
                            selecting = selecting,
                            favorite = f.id in userData.favorites,
                            onClick = { if (selecting) vm.toggleSelect(f.id) else onOpen(f, content.items) },
                            onLongClick = { vm.toggleSelect(f.id) },
                        )
                    }
                }
            }
        }
    }

    // ---------- Diálogos ----------
    when (val d = dialog) {
        is GridDialog.Delete -> ConfirmDialog(
            title = "¿Enviar a la papelera?",
            text = "${d.items.size} elemento(s) irán a la papelera del sistema. Podrás recuperarlos durante unos 30 días.",
            confirmLabel = "Enviar a la papelera",
            destructive = true,
            onConfirm = { actions.trash(d.items) },
            onDismiss = { dialog = null },
        )
        is GridDialog.DeleteForever -> ConfirmDialog(
            title = "¿Eliminar definitivamente?",
            text = "Esta acción no se puede deshacer. Android te pedirá confirmación.",
            confirmLabel = "Eliminar",
            destructive = true,
            onConfirm = { actions.deletePermanently(d.items) },
            onDismiss = { dialog = null },
        )
        is GridDialog.AddToAlbum -> AlbumPickerDialog(
            albums = albums,
            onPick = { a -> vm.addToAlbum(a.id, d.ids); vm.toast("Añadido a «${a.name}»"); vm.clearSelection() },
            onNew = { name -> vm.createAlbum(name, d.ids); vm.toast("Álbum «$name» creado"); vm.clearSelection() },
            onDismiss = { dialog = null },
        )
        is GridDialog.Copy -> TextInputDialog(
            title = "Copiar a carpeta",
            label = "Carpeta (en Imágenes o Películas)",
            initial = "Lumina",
            confirmLabel = "Copiar",
            onConfirm = { vm.copyTo(d.items, it); vm.clearSelection() },
            onDismiss = { dialog = null },
        )
        is GridDialog.Move -> TextInputDialog(
            title = "Mover a carpeta",
            label = "Carpeta (en Imágenes o Películas)",
            initial = "Lumina",
            confirmLabel = "Mover",
            onConfirm = { actions.move(d.items, it) },
            onDismiss = { dialog = null },
        )
        GridDialog.Filters -> FiltersDialog(vm, onDismiss = { dialog = null })
        null -> Unit
    }
}

@Composable
private fun FiltersDialog(vm: MainViewModel, onDismiss: () -> Unit) {
    val options by vm.options.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Listo") } },
        title = { Text("Filtros y orden") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                ChipGroup("Fecha") {
                    DateFilter.entries.forEach {
                        FilterChip(options.date == it, { vm.setDate(it) }, { Text(it.label) })
                    }
                }
                ChipGroup("Ordenar por") {
                    SortField.entries.forEach {
                        FilterChip(options.sortField == it, { vm.setSort(it) }, { Text(it.label) })
                    }
                }
                ChipGroup("Sentido") {
                    FilterChip(options.descending, { vm.setDescending(true) }, { Text("Descendente") })
                    FilterChip(!options.descending, { vm.setDescending(false) }, { Text("Ascendente") })
                }
                ChipGroup("Tamaño de miniaturas") {
                    ThumbSize.entries.forEach {
                        FilterChip(settings.thumbSize == it, { vm.editSettings { setThumbSize(it) } }, { Text(it.label) })
                    }
                }
            }
        },
    )
}

@Composable
private fun ChipGroup(label: String, chips: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(label, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            chips()
        }
    }
}

/** "Continuar viendo": vídeos con posición guardada, con barra de progreso. */
@Composable
fun ContinueWatchingRow(items: List<Pair<MediaFile, PlaybackPos>>, onPlay: (MediaFile) -> Unit) {
    if (items.isEmpty()) return
    Column {
        SectionHeader("Continuar viendo")
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(horizontal = 2.dp)) {
            items(items, key = { it.first.id }) { (file, pos) ->
                Column(Modifier.width(168.dp).clickable { onPlay(file) }) {
                    Box(Modifier.fillMaxWidth().height(94.dp).clip(RoundedCornerShape(14.dp))) {
                        Thumb(file, 360, Modifier.fillMaxSize())
                        Box(
                            Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(28.dp)
                                .background(Color(0x66000000)),
                        )
                        val frac = if (pos.durationMs > 0) (pos.positionMs.toFloat() / pos.durationMs).coerceIn(0f, 1f) else 0f
                        LinearProgressIndicator(
                            progress = { frac },
                            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(3.dp),
                        )
                    }
                    Text(
                        file.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp,
                        modifier = Modifier.padding(top = 6.dp),
                    )
                    Text(
                        "Continuar en ${formatTime(pos.positionMs)}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}
