package com.lumina.gallery.data

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.database.ContentObserver
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.MediaStore.Files.FileColumns
import android.provider.MediaStore.MediaColumns
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.merge

/**
 * Lee la biblioteca con UNA consulta a MediaStore y se vuelve a ejecutar solo cuando el sistema
 * avisa de cambios (ContentObserver, con debounce) o cuando cambian los permisos.
 */
class MediaRepository(private val context: Context) {

    private val resolver: ContentResolver get() = context.contentResolver
    private val imagesUri = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
    private val videosUri = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)

    @OptIn(FlowPreview::class)
    fun observe(trashed: Boolean, extraTrigger: Flow<Unit>): Flow<List<MediaFile>> =
        merge(flowOf(Unit), changes().debounce(500), extraTrigger)
            .map { query(trashed) }
            .flowOn(Dispatchers.IO)

    private fun changes(): Flow<Unit> = callbackFlow {
        val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean) {
                trySend(Unit)
            }
        }
        resolver.registerContentObserver(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, observer)
        resolver.registerContentObserver(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true, observer)
        awaitClose { resolver.unregisterContentObserver(observer) }
    }.conflate()

    private fun query(trashed: Boolean): List<MediaFile> {
        val projection = arrayOf(
            FileColumns._ID,
            MediaColumns.DISPLAY_NAME,
            FileColumns.MEDIA_TYPE,
            MediaColumns.MIME_TYPE,
            MediaColumns.SIZE,
            MediaColumns.DATE_TAKEN,
            MediaColumns.DATE_MODIFIED,
            MediaColumns.WIDTH,
            MediaColumns.HEIGHT,
            MediaColumns.DURATION,
            MediaColumns.BUCKET_ID,
            MediaColumns.BUCKET_DISPLAY_NAME,
            MediaColumns.RELATIVE_PATH,
        )
        val args = Bundle().apply {
            putString(ContentResolver.QUERY_ARG_SQL_SELECTION, "${FileColumns.MEDIA_TYPE} IN (?, ?)")
            putStringArray(
                ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS,
                arrayOf(
                    FileColumns.MEDIA_TYPE_IMAGE.toString(),
                    FileColumns.MEDIA_TYPE_VIDEO.toString(),
                ),
            )
            putInt(
                MediaStore.QUERY_ARG_MATCH_TRASHED,
                if (trashed) MediaStore.MATCH_ONLY else MediaStore.MATCH_EXCLUDE,
            )
        }
        val out = ArrayList<MediaFile>()
        try {
            resolver.query(MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL), projection, args, null)
                ?.use { c ->
                    val iId = c.getColumnIndexOrThrow(FileColumns._ID)
                    val iName = c.getColumnIndexOrThrow(MediaColumns.DISPLAY_NAME)
                    val iType = c.getColumnIndexOrThrow(FileColumns.MEDIA_TYPE)
                    val iMime = c.getColumnIndexOrThrow(MediaColumns.MIME_TYPE)
                    val iSize = c.getColumnIndexOrThrow(MediaColumns.SIZE)
                    val iTaken = c.getColumnIndexOrThrow(MediaColumns.DATE_TAKEN)
                    val iMod = c.getColumnIndexOrThrow(MediaColumns.DATE_MODIFIED)
                    val iW = c.getColumnIndexOrThrow(MediaColumns.WIDTH)
                    val iH = c.getColumnIndexOrThrow(MediaColumns.HEIGHT)
                    val iDur = c.getColumnIndexOrThrow(MediaColumns.DURATION)
                    val iBid = c.getColumnIndexOrThrow(MediaColumns.BUCKET_ID)
                    val iBname = c.getColumnIndexOrThrow(MediaColumns.BUCKET_DISPLAY_NAME)
                    val iRel = c.getColumnIndexOrThrow(MediaColumns.RELATIVE_PATH)
                    while (c.moveToNext()) {
                        val id = c.getLong(iId)
                        val video = c.getInt(iType) == FileColumns.MEDIA_TYPE_VIDEO
                        val taken = c.getLong(iTaken)
                        val date = if (taken > 0) taken else c.getLong(iMod) * 1000L
                        out += MediaFile(
                            id = id,
                            uri = ContentUris.withAppendedId(if (video) videosUri else imagesUri, id),
                            name = c.getString(iName) ?: "sin_nombre",
                            mime = c.getString(iMime) ?: if (video) "video/*" else "image/*",
                            isVideo = video,
                            size = c.getLong(iSize),
                            dateMillis = date,
                            width = c.getInt(iW),
                            height = c.getInt(iH),
                            durationMs = if (video) c.getLong(iDur) else 0L,
                            bucketId = c.getLong(iBid),
                            bucketName = c.getString(iBname) ?: "Otros",
                            relativePath = c.getString(iRel) ?: "",
                        )
                    }
                }
        } catch (_: SecurityException) {
            // Sin permiso: biblioteca vacía; la pantalla de permisos lo explica.
        }
        return out
    }
}
