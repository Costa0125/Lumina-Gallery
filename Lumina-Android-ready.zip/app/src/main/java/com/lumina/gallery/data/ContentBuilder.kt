package com.lumina.gallery.data

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** Lógica pura (sin Android) para filtrar, ordenar y agrupar. Se ejecuta fuera del hilo principal. */
object ContentBuilder {

    fun build(
        base: List<MediaFile>,
        userData: UserData,
        options: ViewOptions,
        source: Source,
        nowMillis: Long = System.currentTimeMillis(),
    ): Content {
        var list: List<MediaFile> = when (source) {
            Source.Photos, Source.Trash -> base
            Source.Videos -> base.filter { it.isVideo }
            Source.Favorites -> base.filter { it.id in userData.favorites }
            is Source.Folder -> base.filter { it.bucketId == source.bucketId }
            is Source.Album -> {
                val ids = userData.albums.firstOrNull { it.id == source.id }?.items.orEmpty()
                base.filter { it.id in ids }
            }
        }

        if (source != Source.Videos) {
            list = when (options.type) {
                TypeFilter.ALL -> list
                TypeFilter.PHOTOS -> list.filter { !it.isVideo }
                TypeFilter.VIDEOS -> list.filter { it.isVideo }
            }
        }
        options.bucketId?.let { b -> list = list.filter { it.bucketId == b } }
        if (options.date != DateFilter.ANY) {
            val limit = when (options.date) {
                DateFilter.WEEK -> nowMillis - 7L * DAY
                DateFilter.MONTH -> nowMillis - 30L * DAY
                DateFilter.YEAR -> Calendar.getInstance().apply {
                    timeInMillis = nowMillis
                    set(Calendar.DAY_OF_YEAR, 1)
                    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                }.timeInMillis
                DateFilter.ANY -> 0L
            }
            list = list.filter { it.dateMillis >= limit }
        }
        val q = options.query.trim()
        if (q.isNotEmpty()) list = list.filter { it.name.contains(q, ignoreCase = true) }

        val comparator: Comparator<MediaFile> = when (options.sortField) {
            SortField.DATE -> compareBy<MediaFile> { it.dateMillis }.thenBy { it.id }
            SortField.NAME -> compareBy<MediaFile, String>(String.CASE_INSENSITIVE_ORDER) { it.name }
            SortField.SIZE -> compareBy<MediaFile> { it.size }.thenBy { it.id }
        }
        list = list.sortedWith(if (options.descending) comparator.reversed() else comparator)

        val sections = if (options.sortField == SortField.DATE) {
            groupByDate(list, nowMillis)
        } else {
            if (list.isEmpty()) emptyList() else listOf(Section("", list))
        }
        return Content(list, sections)
    }

    /** Hoy, Ayer, Esta semana, Este mes, meses anteriores del año y años anteriores. */
    fun groupByDate(sorted: List<MediaFile>, nowMillis: Long): List<Section> {
        val cal = Calendar.getInstance().apply { timeInMillis = nowMillis }
        val todayStart = (cal.clone() as Calendar).apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val yesterdayStart = todayStart - DAY
        val weekStart = todayStart - 6 * DAY
        val monthStart = (cal.clone() as Calendar).apply {
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val currentYear = cal.get(Calendar.YEAR)
        val monthFormat = SimpleDateFormat("LLLL", Locale.getDefault())

        val groups = LinkedHashMap<String, MutableList<MediaFile>>()
        val tmp = Calendar.getInstance()
        for (m in sorted) {
            val d = m.dateMillis
            val label = when {
                d >= todayStart -> "Hoy"
                d >= yesterdayStart -> "Ayer"
                d >= weekStart -> "Esta semana"
                d >= monthStart -> "Este mes"
                else -> {
                    tmp.timeInMillis = d
                    if (tmp.get(Calendar.YEAR) == currentYear) {
                        monthFormat.format(tmp.time).replaceFirstChar { it.uppercase() }
                    } else {
                        tmp.get(Calendar.YEAR).toString()
                    }
                }
            }
            groups.getOrPut(label) { ArrayList() }.add(m)
        }
        return groups.map { (title, items) -> Section(title, items) }
    }

    fun folders(base: List<MediaFile>): List<FolderInfo> =
        base.groupBy { it.bucketId }.map { (id, files) ->
            val newest = files.maxByOrNull { it.dateMillis }!!
            FolderInfo(id, newest.bucketName, files.size, newest)
        }.sortedByDescending { it.count }

    const val DAY = 24L * 60 * 60 * 1000
}
