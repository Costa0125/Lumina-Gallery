@file:OptIn(UnstableApi::class)

package com.lumina.gallery.player

import android.content.res.Configuration
import android.view.LayoutInflater
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.offset
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.BrightnessMedium
import androidx.compose.material.icons.rounded.FitScreen
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Replay
import androidx.compose.material.icons.rounded.ScreenRotation
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material.icons.rounded.ZoomIn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.lumina.gallery.R
import com.lumina.gallery.data.AppSettings
import com.lumina.gallery.data.FrameMode
import com.lumina.gallery.data.formatTime
import kotlinx.coroutines.delay
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

/** Lo que el reproductor necesita de la actividad (ventana, audio, orientación). */
interface PlayerHost {
    fun close()
    fun retry()
    /** Cada pulsación cambia visiblemente: la otra orientación -> la actual (fija) -> automática. Devuelve una etiqueta. */
    fun cycleOrientation(): String
    fun currentBrightness(): Float
    fun setBrightness(value: Float)
    fun maxVolume(): Int
    fun currentVolume(): Int
    fun setVolume(value: Int)
}

/** Estado observable del reproductor, actualizado por un único listener (onEvents). */
@Stable
class PlayerUiState(private val player: Player) : Player.Listener {
    var isPlaying by mutableStateOf(player.isPlaying)
    var playWhenReady by mutableStateOf(player.playWhenReady)
    var state by mutableIntStateOf(player.playbackState)
    var durationMs by mutableLongStateOf(player.duration)
    var tracks by mutableStateOf(player.currentTracks)
    var speed by mutableFloatStateOf(player.playbackParameters.speed)
    var error by mutableStateOf(player.playerError)
    var muted by mutableStateOf(player.volume == 0f)

    fun refresh() {
        isPlaying = player.isPlaying
        playWhenReady = player.playWhenReady
        state = player.playbackState
        durationMs = player.duration
        tracks = player.currentTracks
        speed = player.playbackParameters.speed
        error = player.playerError
        muted = player.volume == 0f
    }

    override fun onEvents(player: Player, events: Player.Events) = refresh()
}

private data class Osd(val text: String, val id: Long)

@Composable
fun PlayerScreen(
    player: ExoPlayer,
    settings: AppSettings,
    title: String,
    resumeNotice: String?,
    host: PlayerHost,
) {
    val ui = remember(player) { PlayerUiState(player) }
    DisposableEffect(player) {
        player.addListener(ui)
        ui.refresh()
        onDispose { player.removeListener(ui) }
    }

    var controlsVisible by remember { mutableStateOf(true) }
    var interaction by remember { mutableIntStateOf(0) }
    var scrubbing by remember { mutableStateOf(false) }
    var adjusting by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var frame by remember { mutableStateOf(settings.frameMode) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var pan by remember { mutableStateOf(Offset.Zero) }
    var brightness by remember { mutableFloatStateOf(host.currentBrightness()) }
    val maxVolume = remember { host.maxVolume().coerceAtLeast(1) }
    var volume by remember { mutableIntStateOf(host.currentVolume()) }
    var osd by remember { mutableStateOf<Osd?>(null) }
    var positionMs by remember { mutableLongStateOf(player.currentPosition) }
    var showRemaining by remember { mutableStateOf(false) }
    var scrubMs by remember { mutableFloatStateOf(0f) }
    var scrubStartMs by remember { mutableLongStateOf(0L) }
    var wasPlayingBeforeScrub by remember { mutableStateOf(false) }
    val haptic = LocalHapticFeedback.current
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val seekMs = settings.seekSeconds * 1000L

    fun bump() { interaction++ }
    fun show(text: String) { osd = Osd(text, System.nanoTime()) }
    fun tick() { if (settings.haptics) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) }

    fun seekBy(deltaMs: Long) {
        var target = (player.currentPosition + deltaMs).coerceAtLeast(0L)
        val dur = player.duration
        if (dur > 0) target = target.coerceAtMost(dur)
        player.seekTo(target)
        positionMs = target
    }

    fun togglePlay() {
        if (player.playbackState == Player.STATE_ENDED) {
            player.seekTo(0)
            player.play()
        } else if (player.playWhenReady) {
            player.pause()
        } else {
            player.play()
        }
    }

    // --- Ocultación automática. Cada cambio de clave cancela y reinicia el temporizador. ---
    // Se oculta solo si: hay reproducción activa, no se arrastra la barra, no se ajusta brillo/volumen
    // y no hay menú abierto. En pausa, error o fin, los controles permanecen visibles.
    LaunchedEffect(
        controlsVisible, ui.playWhenReady, ui.state, ui.error, interaction, scrubbing, adjusting, menuOpen,
    ) {
        val canAutoHide = controlsVisible && ui.playWhenReady && ui.state != Player.STATE_ENDED &&
            ui.error == null && !scrubbing && !adjusting && !menuOpen
        if (canAutoHide) {
            delay(settings.hideSeconds * 1000L)
            controlsVisible = false
        }
    }
    LaunchedEffect(ui.state, ui.error) {
        if (ui.state == Player.STATE_ENDED || ui.error != null) controlsVisible = true
    }

    // --- Posición y volumen (sincroniza con botones físicos). Sondeo rápido solo con controles visibles. ---
    LaunchedEffect(player, controlsVisible) {
        while (true) {
            if (!scrubbing) positionMs = player.currentPosition
            if (!adjusting) volume = host.currentVolume()
            delay(if (controlsVisible) 200L else 1000L)
        }
    }

    // --- Arrastre de la barra: búsqueda throttled a keyframes; al soltar, búsqueda exacta. ---
    LaunchedEffect(scrubbing) {
        if (scrubbing) {
            player.setSeekParameters(SeekParameters.CLOSEST_SYNC)
            var last = -1L
            while (true) {
                val t = scrubMs.toLong()
                if (t != last) {
                    player.seekTo(t)
                    last = t
                }
                delay(180L)
            }
        } else {
            player.setSeekParameters(SeekParameters.EXACT)
        }
    }

    LaunchedEffect(osd) {
        if (osd != null) {
            delay(1000L)
            osd = null
        }
    }
    LaunchedEffect(Unit) { resumeNotice?.let { show(it) } }

    val view = LocalView.current
    SideEffect { view.keepScreenOn = ui.playWhenReady && ui.state != Player.STATE_ENDED }

    Box(Modifier.fillMaxSize().background(Color.Black)) {

        // 1) Vídeo. Fit/Fill con resize_mode (sin deformar nunca); zoom manual con transformación.
        AndroidView(
            factory = { ctx -> LayoutInflater.from(ctx).inflate(R.layout.view_player, null) as PlayerView },
            update = { v ->
                v.player = player
                v.resizeMode = if (frame == FrameMode.FILL) {
                    AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                } else {
                    AspectRatioFrameLayout.RESIZE_MODE_FIT
                }
            },
            onRelease = { it.player = null },
            modifier = Modifier.fillMaxSize().graphicsLayer {
                scaleX = zoom
                scaleY = zoom
                translationX = pan.x
                translationY = pan.y
            },
        )

        // 2) Capa de gestos. Debajo de los controles: los botones consumen sus propios toques y
        //    un toque en zona vacía llega aquí (mostrar/ocultar controles).
        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(settings.gestures, settings.doubleTapCenterPause, seekMs) {
                    detectTapGestures(
                        onTap = {
                            if (controlsVisible) {
                                controlsVisible = false
                            } else {
                                controlsVisible = true
                                bump()
                            }
                        },
                        onDoubleTap = if (settings.gestures) {
                            { o ->
                                val w = size.width
                                when {
                                    o.x < w / 3f -> {
                                        seekBy(-seekMs); tick()
                                        show("−${settings.seekSeconds} s")
                                    }
                                    o.x > w * 2f / 3f -> {
                                        seekBy(seekMs); tick()
                                        show("+${settings.seekSeconds} s")
                                    }
                                    settings.doubleTapCenterPause -> {
                                        togglePlay(); tick()
                                    }
                                }
                            }
                        } else {
                            null
                        },
                    )
                }
                .pointerInput(settings.gestures) {
                    if (!settings.gestures) return@pointerInput
                    var side = 0 // 0 = ignorar, 1 = brillo (izquierda), 2 = volumen (derecha)
                    var volAccum = 0f
                    detectVerticalDragGestures(
                        onDragStart = { o ->
                            val edge = 28.dp.toPx() // evita el gesto de atrás del sistema
                            side = when {
                                o.x < edge || o.x > size.width - edge -> 0
                                o.x < size.width / 2f -> 1
                                else -> 2
                            }
                            if (side != 0) adjusting = true
                            volAccum = volume.toFloat()
                            brightness = host.currentBrightness()
                        },
                        onDragEnd = { adjusting = false; side = 0 },
                        onDragCancel = { adjusting = false; side = 0 },
                        onVerticalDrag = { change, dy ->
                            if (side != 0) {
                                change.consume()
                                val frac = -dy / (size.height * 0.75f)
                                if (side == 1) {
                                    brightness = (brightness + frac).coerceIn(0.01f, 1f)
                                    host.setBrightness(brightness)
                                    show("Brillo ${(brightness * 100).roundToInt()}%")
                                } else {
                                    volAccum = (volAccum + frac * maxVolume).coerceIn(0f, maxVolume.toFloat())
                                    volume = volAccum.roundToInt()
                                    host.setVolume(volume)
                                    show("Volumen ${(volume * 100f / maxVolume).roundToInt()}%")
                                }
                            }
                        },
                    )
                }
                .pointerInput(frame) {
                    if (frame != FrameMode.ZOOM) return@pointerInput
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false)
                        do {
                            val event = awaitPointerEvent()
                            if (event.changes.size >= 2) { // solo con dos dedos: no choca con otros gestos
                                val z = event.calculateZoom()
                                val p = event.calculatePan()
                                if (z != 1f || p != Offset.Zero) {
                                    zoom = (zoom * z).coerceIn(1f, 5f)
                                    val maxX = size.width * (zoom - 1f) / 2f
                                    val maxY = size.height * (zoom - 1f) / 2f
                                    pan = Offset(
                                        (pan.x + p.x).coerceIn(-maxX, maxX),
                                        (pan.y + p.y).coerceIn(-maxY, maxY),
                                    )
                                    event.changes.forEach { if (it.positionChanged()) it.consume() }
                                    show("Zoom ${String.format(Locale.US, "%.1f", zoom)}×")
                                }
                            }
                        } while (event.changes.any { it.pressed })
                    }
                },
        )

        // 3) Indicador de carga cuando los controles no se ven.
        if (ui.state == Player.STATE_BUFFERING && ui.error == null && !controlsVisible) {
            CircularProgressIndicator(Modifier.align(Alignment.Center), color = Color.White)
        }

        // 4) Controles.
        AnimatedVisibility(
            visible = controlsVisible && ui.error == null,
            enter = fadeIn(tween(150)),
            exit = fadeOut(tween(220)),
            modifier = Modifier.fillMaxSize(),
        ) {
            Box(Modifier.fillMaxSize()) {
                Box(
                    Modifier.fillMaxWidth().height(120.dp).align(Alignment.TopCenter)
                        .background(Brush.verticalGradient(listOf(Color(0xCC000000), Color.Transparent))),
                )
                Box(
                    Modifier.fillMaxWidth().height(200.dp).align(Alignment.BottomCenter)
                        .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xE6000000)))),
                )

                // Barra superior
                Row(
                    Modifier.align(Alignment.TopCenter).fillMaxWidth().safeDrawingPadding()
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    RoundButton(Icons.AutoMirrored.Rounded.ArrowBack, "Volver") { host.close() }
                    Text(
                        title,
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                    )
                    RoundButton(Icons.Rounded.MoreVert, "Más opciones") { menuOpen = true; bump() }
                }

                // Centro: retroceder / reproducir-pausar / adelantar
                Row(
                    Modifier.align(Alignment.Center),
                    horizontalArrangement = Arrangement.spacedBy(28.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    SeekIcon(forward = false, seconds = settings.seekSeconds) {
                        seekBy(-seekMs); tick(); bump()
                    }
                    Box(
                        Modifier.size(76.dp).clip(CircleShape).background(Color(0x59000000))
                            .clickable { togglePlay(); bump() },
                        contentAlignment = Alignment.Center,
                    ) {
                        if (ui.state == Player.STATE_BUFFERING && ui.playWhenReady) {
                            CircularProgressIndicator(Modifier.size(40.dp), color = Color.White, strokeWidth = 3.dp)
                        } else {
                            Icon(
                                imageVector = when {
                                    ui.state == Player.STATE_ENDED -> Icons.Rounded.Replay
                                    ui.playWhenReady -> Icons.Rounded.Pause
                                    else -> Icons.Rounded.PlayArrow
                                },
                                contentDescription = if (ui.playWhenReady) "Pausar" else "Reproducir",
                                tint = Color.White,
                                modifier = Modifier.size(44.dp),
                            )
                        }
                    }
                    SeekIcon(forward = true, seconds = settings.seekSeconds) {
                        seekBy(seekMs); tick(); bump()
                    }
                }

                // Brillo (izquierda) y volumen (derecha): solo visibles con los controles.
                val sliderHeight = if (landscape) 130.dp else 190.dp
                val sliderLift = if (landscape) 44.dp else 0.dp
                Box(
                    Modifier.align(Alignment.CenterStart).safeDrawingPadding()
                        .padding(start = 12.dp, bottom = sliderLift),
                ) {
                    VerticalLevel(
                        value = brightness,
                        icon = Icons.Rounded.BrightnessMedium,
                        description = "Brillo",
                        height = sliderHeight,
                        onStart = { adjusting = true },
                        onChange = { brightness = it.coerceAtLeast(0.01f); host.setBrightness(brightness) },
                        onEnd = { adjusting = false; bump() },
                    )
                }
                Box(
                    Modifier.align(Alignment.CenterEnd).safeDrawingPadding()
                        .padding(end = 12.dp, bottom = sliderLift),
                ) {
                    VerticalLevel(
                        value = volume.toFloat() / maxVolume,
                        icon = if (volume == 0 || ui.muted) Icons.Rounded.VolumeOff else Icons.Rounded.VolumeUp,
                        description = "Volumen",
                        height = sliderHeight,
                        onStart = { adjusting = true },
                        onChange = {
                            volume = (it * maxVolume).roundToInt().coerceIn(0, maxVolume)
                            host.setVolume(volume)
                        },
                        onEnd = { adjusting = false; bump() },
                    )
                }

                // Barra inferior: progreso + botones
                Column(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth().safeDrawingPadding()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                ) {
                    val duration = ui.durationMs
                    val known = duration > 0L
                    val shownPos = if (scrubbing) scrubMs.toLong() else positionMs
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(formatTime(shownPos), color = Color.White, fontSize = 13.sp)
                        Slider(
                            value = if (scrubbing) {
                                scrubMs
                            } else if (known) {
                                positionMs.coerceIn(0L, duration).toFloat()
                            } else {
                                0f
                            },
                            onValueChange = { v ->
                                if (!scrubbing) {
                                    wasPlayingBeforeScrub = player.playWhenReady
                                    scrubStartMs = player.currentPosition
                                    player.pause()
                                    scrubbing = true
                                }
                                scrubMs = v
                                bump()
                            },
                            onValueChangeFinished = {
                                player.setSeekParameters(SeekParameters.EXACT)
                                val target = scrubMs.toLong()
                                player.seekTo(target)
                                positionMs = target
                                scrubbing = false
                                if (wasPlayingBeforeScrub) player.play()
                                bump()
                            },
                            valueRange = 0f..(if (known) duration.toFloat() else 1f),
                            enabled = known,
                            colors = SliderDefaults.colors(
                                thumbColor = MaterialTheme.colorScheme.primary,
                                activeTrackColor = MaterialTheme.colorScheme.primary,
                                inactiveTrackColor = Color(0x4DFFFFFF),
                                disabledThumbColor = Color(0x80FFFFFF),
                                disabledActiveTrackColor = Color(0x4DFFFFFF),
                                disabledInactiveTrackColor = Color(0x33FFFFFF),
                            ),
                            modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                        )
                        Text(
                            text = when {
                                !known -> "--:--"
                                showRemaining -> "−" + formatTime((duration - shownPos).coerceAtLeast(0L))
                                else -> formatTime(duration)
                            },
                            color = Color.White,
                            fontSize = 13.sp,
                            modifier = Modifier.clickable { showRemaining = !showRemaining; bump() },
                        )
                    }
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterHorizontally),
                    ) {
                        PillButton(
                            icon = when (frame) {
                                FrameMode.FIT -> Icons.Rounded.FitScreen
                                FrameMode.FILL -> Icons.Rounded.Fullscreen
                                FrameMode.ZOOM -> Icons.Rounded.ZoomIn
                            },
                            text = frame.label,
                        ) {
                            frame = when (frame) {
                                FrameMode.FIT -> FrameMode.FILL
                                FrameMode.FILL -> FrameMode.ZOOM
                                FrameMode.ZOOM -> FrameMode.FIT
                            }
                            zoom = 1f
                            pan = Offset.Zero
                            show(
                                when (frame) {
                                    FrameMode.FIT -> "Ajustar a pantalla"
                                    FrameMode.FILL -> "Rellenar pantalla"
                                    FrameMode.ZOOM -> "Zoom: pellizca con dos dedos"
                                },
                            )
                            bump()
                        }
                        if (frame == FrameMode.ZOOM && (zoom != 1f || pan != Offset.Zero)) {
                            PillButton(icon = Icons.Rounded.Replay, text = "Restablecer") {
                                zoom = 1f
                                pan = Offset.Zero
                                show("Encuadre restablecido")
                                bump()
                            }
                        }
                        PillButton(icon = Icons.Rounded.ScreenRotation, text = "Rotar") {
                            show(host.cycleOrientation())
                            bump()
                        }
                        PillButton(
                            icon = if (ui.muted) Icons.Rounded.VolumeOff else Icons.Rounded.VolumeUp,
                            text = if (ui.muted) "Activar sonido" else "Silenciar",
                        ) {
                            player.volume = if (ui.muted) 1f else 0f
                            bump()
                        }
                        PillButton(
                            icon = Icons.Rounded.Speed,
                            text = formatSpeed(ui.speed),
                        ) { menuOpen = true; bump() }
                    }
                }

                // Vista previa del tiempo mientras se arrastra la barra
                if (scrubbing) {
                    val delta = scrubMs.toLong() - scrubStartMs
                    Surface(
                        color = Color(0xCC000000),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.align(Alignment.Center).offset { IntOffset(0, -170) },
                    ) {
                        Column(
                            Modifier.padding(horizontal = 18.dp, vertical = 10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Text(formatTime(scrubMs.toLong()), color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.SemiBold)
                            Text(
                                (if (delta >= 0) "+" else "−") + formatTime(abs(delta)),
                                color = Color(0xFFFFB86B),
                                fontSize = 13.sp,
                            )
                        }
                    }
                }
            }
        }

        // 5) Indicador temporal (gestos, cambios de modo, zoom...)
        osd?.let { o ->
            Surface(
                color = Color(0xB3000000),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.align(Alignment.TopCenter).safeDrawingPadding().padding(top = 56.dp),
            ) {
                Text(
                    o.text,
                    color = Color.White,
                    fontSize = 16.sp,
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp),
                )
            }
        }

        // 6) Error comprensible
        ui.error?.let { err ->
            Surface(
                color = Color(0xE6101014),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.align(Alignment.Center).padding(24.dp).safeDrawingPadding(),
            ) {
                Column(
                    Modifier.padding(24.dp).widthIn(max = 420.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Icon(Icons.Rounded.Warning, null, tint = Color(0xFFFFB86B), modifier = Modifier.size(40.dp))
                    Text("No se puede reproducir este vídeo", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
                    Text(describeError(err), color = Color(0xFFCFCFDA), fontSize = 14.sp, textAlign = TextAlign.Center)
                    Text("Detalle técnico: ${err.errorCodeName}", color = Color(0xFF8E8E9A), fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedButton(onClick = { host.close() }) { Text("Cerrar") }
                        Button(onClick = { host.retry() }) { Text("Reintentar") }
                    }
                }
            }
        }
    }

    if (menuOpen) {
        OptionsDialog(player = player, ui = ui, onDismiss = { menuOpen = false; bump() })
    }
}

/** 1.0 -> "1×", 0.75 -> "0.75×", 1.25 -> "1.25×". */
private fun formatSpeed(s: Float): String {
    val txt = String.format(Locale.US, "%.2f", s).trimEnd('0').trimEnd('.')
    return "$txt×"
}

private fun describeError(e: PlaybackException): String = when (e.errorCode) {
    PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,
    PlaybackException.ERROR_CODE_DECODING_FAILED,
    PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES,
    PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED ->
        "Este teléfono no puede decodificar el códec o la resolución de este archivo. " +
            "Prueba con otro reproductor que incluya decodificación por software."
    PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED ->
        "El archivo parece dañado o está incompleto (descarga interrumpida, por ejemplo)."
    PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED ->
        "El formato del contenedor del archivo no es compatible."
    PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND ->
        "No se encontró el archivo. Puede haberse movido o eliminado."
    PlaybackException.ERROR_CODE_IO_NO_PERMISSION ->
        "La aplicación no tiene permiso para leer este archivo."
    PlaybackException.ERROR_CODE_AUDIO_TRACK_INIT_FAILED,
    PlaybackException.ERROR_CODE_AUDIO_TRACK_WRITE_FAILED ->
        "Falló la salida de audio. Comprueba los auriculares o el dispositivo Bluetooth e inténtalo de nuevo."
    else -> "Ocurrió un error inesperado durante la reproducción."
}

// ----------------------------------------------------------------------------------------------
// Componentes
// ----------------------------------------------------------------------------------------------

@Composable
private fun RoundButton(icon: ImageVector, description: String, onClick: () -> Unit) {
    Box(
        Modifier.size(48.dp).clip(CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, description, tint = Color.White, modifier = Modifier.size(26.dp))
    }
}

@Composable
private fun SeekIcon(forward: Boolean, seconds: Int, onClick: () -> Unit) {
    Box(
        Modifier.size(58.dp).clip(CircleShape).background(Color(0x40000000)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            Icons.Rounded.Replay,
            if (forward) "Adelantar $seconds segundos" else "Retroceder $seconds segundos",
            tint = Color.White,
            modifier = Modifier.size(38.dp).graphicsLayer { scaleX = if (forward) -1f else 1f },
        )
        Text("$seconds", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun PillButton(icon: ImageVector, text: String, onClick: () -> Unit) {
    Row(
        Modifier.height(44.dp).clip(RoundedCornerShape(22.dp)).background(Color(0x33FFFFFF))
            .clickable(onClick = onClick).padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(20.dp))
        Text(text, color = Color.White, fontSize = 13.sp, maxLines = 1)
    }
}

/** Deslizador vertical propio: toque o arrastre ajustan el valor 0..1 al instante. */
@Composable
private fun VerticalLevel(
    value: Float,
    icon: ImageVector,
    description: String,
    height: androidx.compose.ui.unit.Dp,
    onStart: () -> Unit,
    onChange: (Float) -> Unit,
    onEnd: () -> Unit,
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("${(value * 100).roundToInt()}", color = Color.White, fontSize = 12.sp)
        Box(
            Modifier
                .width(44.dp)
                .height(height)
                .clip(RoundedCornerShape(22.dp))
                .background(Color(0x40FFFFFF))
                .pointerInput(Unit) {
                    awaitEachGesture {
                        val down = awaitFirstDown()
                        onStart()
                        fun update(y: Float) = onChange((1f - y / size.height).coerceIn(0f, 1f))
                        update(down.position.y)
                        down.consume()
                        do {
                            val event = awaitPointerEvent()
                            event.changes.firstOrNull()?.let {
                                update(it.position.y)
                                it.consume()
                            }
                        } while (event.changes.any { it.pressed })
                        onEnd()
                    }
                },
            contentAlignment = Alignment.BottomCenter,
        ) {
            Box(
                Modifier.fillMaxWidth().fillMaxHeight(value.coerceIn(0f, 1f))
                    .background(Color(0xE6FFFFFF)),
            )
            Icon(
                icon,
                description,
                tint = Color(0xFF1B1B22),
                modifier = Modifier.padding(bottom = 10.dp).size(22.dp),
            )
        }
    }
}

@Composable
private fun OptionsDialog(player: ExoPlayer, ui: PlayerUiState, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } },
        title = { Text("Opciones de reproducción") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Velocidad", fontWeight = FontWeight.SemiBold)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { s ->
                        FilterChip(
                            selected = abs(ui.speed - s) < 0.01f,
                            onClick = { player.setPlaybackSpeed(s) },
                            label = { Text(formatSpeed(s)) },
                        )
                    }
                }

                val audio = ui.tracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO && it.isSupported }
                Text("Audio", fontWeight = FontWeight.SemiBold)
                if (audio.isEmpty()) {
                    Text("Solo hay una pista de audio.", fontSize = 13.sp)
                } else {
                    audio.forEach { g ->
                        for (i in 0 until g.length) {
                            TrackRow(trackLabel(g.getTrackFormat(i), i), g.isTrackSelected(i)) {
                                selectTrack(player, C.TRACK_TYPE_AUDIO, g, i)
                            }
                        }
                    }
                }

                val text = ui.tracks.groups.filter { it.type == C.TRACK_TYPE_TEXT && it.isSupported }
                Text("Subtítulos", fontWeight = FontWeight.SemiBold)
                if (text.isEmpty()) {
                    Text("Este vídeo no tiene subtítulos disponibles.", fontSize = 13.sp)
                } else {
                    val anySelected = text.any { it.isSelected }
                    TrackRow("Desactivados", !anySelected) { selectTrack(player, C.TRACK_TYPE_TEXT, null, 0) }
                    text.forEach { g ->
                        for (i in 0 until g.length) {
                            TrackRow(trackLabel(g.getTrackFormat(i), i), g.isTrackSelected(i)) {
                                selectTrack(player, C.TRACK_TYPE_TEXT, g, i)
                            }
                        }
                    }
                }
            }
        },
    )
}

@Composable
private fun TrackRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Text(label, fontSize = 14.sp)
    }
}

private fun selectTrack(player: Player, type: Int, group: Tracks.Group?, trackIndex: Int) {
    val builder = player.trackSelectionParameters.buildUpon()
    if (group == null) {
        builder.setTrackTypeDisabled(type, true)
    } else {
        builder.setTrackTypeDisabled(type, false)
        builder.setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, trackIndex))
    }
    player.trackSelectionParameters = builder.build()
}

private fun trackLabel(f: Format, index: Int): String {
    val lang = f.language?.takeIf { it != "und" }
        ?.let { Locale.forLanguageTag(it).displayLanguage.replaceFirstChar { c -> c.uppercase() } }
    val channels = f.channelCount.takeIf { it > 0 }?.let { "${it} canales" }
    val parts = listOfNotNull(f.label, lang, channels).distinct()
    return parts.joinToString(" · ").ifBlank { "Pista ${index + 1}" }
}
