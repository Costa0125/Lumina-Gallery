package com.lumina.gallery.data

import android.net.Uri

/** Un archivo multimedia (foto, GIF, captura o vídeo) tal como lo expone MediaStore. */
data class MediaFile(
    val id: Long,
    val uri: Uri,
    val name: String,
    val mime: String,
    val isVideo: Boolean,
    val size: Long,
    val dateMillis: Long,
    val width: Int,
    val height: Int,
    val durationMs: Long,
    val bucketId: Long,
    val bucketName: String,
    val relativePath: String,
) {
    val isGif: Boolean get() = mime == "image/gif"

    /** Clave estable para guardar la posición de reproducción. */
    val positionKey: String get() = "id:$id"
}

enum class ThemeMode(val label: String) { SYSTEM("Automático"), LIGHT("Claro"), DARK("Oscuro") }
enum class FrameMode(val label: String) { FIT("Ajustar"), FILL("Rellenar"), ZOOM("Zoom") }
enum class ThumbSize(val label: String, val minDp: Int, val requestPx: Int) {
    SMALL("Pequeñas", 82, 256),
    MEDIUM("Medianas", 112, 320),
    LARGE("Grandes", 160, 480),
}
enum class SortField(val label: String) { DATE("Fecha"), NAME("Nombre"), SIZE("Tamaño") }
enum class TypeFilter(val label: String) { ALL("Todo"), PHOTOS("Fotos"), VIDEOS("Vídeos") }
enum class DateFilter(val label: String) {
    ANY("Cualquier fecha"), WEEK("Últimos 7 días"), MONTH("Últimos 30 días"), YEAR("Este año")
}

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val hideSeconds: Int = 4,
    val defaultSpeed: Float = 1f,
    val gestures: Boolean = true,
    val doubleTapCenterPause: Boolean = false,
    val seekSeconds: Int = 10,
    val frameMode: FrameMode = FrameMode.FIT,
    val resume: Boolean = true,
    val thumbSize: ThumbSize = ThumbSize.MEDIUM,
    val defaultSort: SortField = SortField.DATE,
    val haptics: Boolean = true,
)

data class PlaybackPos(val positionMs: Long, val durationMs: Long, val updatedAt: Long)
data class UserAlbum(val id: String, val name: String, val items: Set<Long>)
data class UserData(
    val favorites: Set<Long> = emptySet(),
    val albums: List<UserAlbum> = emptyList(),
    val positions: Map<String, PlaybackPos> = emptyMap(),
)

/** Qué lista se está mostrando. */
sealed interface Source {
    data object Photos : Source
    data object Videos : Source
    data object Favorites : Source
    data object Trash : Source
    data class Folder(val bucketId: Long, val name: String) : Source
    data class Album(val id: String, val name: String) : Source
}

data class ViewOptions(
    val query: String = "",
    val type: TypeFilter = TypeFilter.ALL,
    val date: DateFilter = DateFilter.ANY,
    val bucketId: Long? = null,
    val sortField: SortField = SortField.DATE,
    val descending: Boolean = true,
)

data class Section(val title: String, val items: List<MediaFile>)
data class Content(val items: List<MediaFile>, val sections: List<Section>) {
    companion object {
        val Empty = Content(emptyList(), emptyList())
    }
}

data class FolderInfo(val bucketId: Long, val name: String, val count: Int, val cover: MediaFile)
data class AlbumInfo(val album: UserAlbum, val count: Int, val cover: MediaFile?)
