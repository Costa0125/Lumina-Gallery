@file:OptIn(UnstableApi::class)

package com.lumina.gallery.player

import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.SeekParameters
import com.lumina.gallery.LuminaApp
import com.lumina.gallery.data.SettingsRepository
import com.lumina.gallery.data.UserDataRepository
import com.lumina.gallery.data.AppSettings
import com.lumina.gallery.data.formatTime
import com.lumina.gallery.ui.theme.LuminaTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

class VideoPlayerActivity : ComponentActivity(), PlayerHost {

    private var player: ExoPlayer? = null
    private lateinit var audio: AudioManager
    private lateinit var userData: UserDataRepository
    private lateinit var appScope: CoroutineScope

    private var settings = AppSettings()
    private var uri: Uri? = null
    private var positionKey = ""
    private var title = ""
    private var resumeNotice: String? = null
    private var originalBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
    private var orientationState = 0
    private var originalLandscape = false
    private var wasPlayingOnStop = false
    private var ready by mutableStateOf(false)
    private var generation by mutableStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)

        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        userData = UserDataRepository(applicationContext)
        appScope = (application as LuminaApp).appScope
        volumeControlStream = AudioManager.STREAM_MUSIC // los botones físicos controlan el volumen multimedia

        uri = intent.data
        if (uri == null) {
            finish()
            return
        }
        title = intent.getStringExtra(EXTRA_TITLE) ?: queryName(uri!!) ?: "Vídeo"
        positionKey = intent.getStringExtra(EXTRA_KEY) ?: "uri:${uri.toString().hashCode()}"
        originalBrightness = window.attributes.screenBrightness

        // Ajustes y posición guardada se leen una vez, antes de crear el reproductor.
        settings = runBlocking { SettingsRepository(applicationContext).flow.first() }
        val saved = if (settings.resume) runBlocking { userData.getPosition(positionKey) } else null

        setContent {
            LuminaTheme(settings.themeMode, forceDark = true) {
                // Se recompone al reintentar (generation) y cuando el reproductor está listo.
                val p = player
                if (ready && p != null) {
                    androidx.compose.runtime.key(generation) {
                        PlayerScreen(p, settings, title, resumeNotice, this@VideoPlayerActivity)
                    }
                }
            }
        }

        createPlayer(saved)
        hideSystemBars()
    }

    private fun createPlayer(saved: com.lumina.gallery.data.PlaybackPos?) {
        releasePlayer()
        val renderers = DefaultRenderersFactory(this)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
            .setEnableDecoderFallback(true) // si un decodificador falla, intenta con otro del sistema
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 40_000, 1_500, 3_000) // memoria acotada incluso en películas de horas
            .build()
        val p = ExoPlayer.Builder(this, renderers)
            .setLoadControl(loadControl)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(),
                true, // gestiona el foco de audio: pausa en llamadas y otras interrupciones
            )
            .setHandleAudioBecomingNoisy(true) // pausa al desconectar auriculares/Bluetooth
            .setSeekParameters(SeekParameters.EXACT)
            .build()
        p.setMediaItem(MediaItem.fromUri(uri!!))
        p.setPlaybackSpeed(settings.defaultSpeed)
        if (saved != null && saved.durationMs > 0) {
            val nearEnd = saved.positionMs > saved.durationMs - 5_000
            if (saved.positionMs > 3_000 && !nearEnd) {
                p.seekTo(saved.positionMs)
                resumeNotice = "Continuando desde ${formatTime(saved.positionMs)}"
            }
        }
        p.playWhenReady = true
        p.prepare()
        player = p
        ready = true
    }

    private fun releasePlayer() {
        player?.let {
            saveProgress(it)
            it.release()
        }
        player = null
    }

    private fun saveProgress(p: Player) {
        if (!settings.resume || positionKey.isEmpty()) return
        val dur = p.duration
        val pos = p.currentPosition
        if (dur <= 0) return
        val key = positionKey
        appScope.launch {
            if (pos > dur - 5_000 || pos < 3_000) userData.clearPosition(key)
            else userData.savePosition(key, pos, dur)
        }
    }

    // --- PlayerHost -----------------------------------------------------------------------

    override fun close() = finish()

    override fun retry() {
        val pos = player?.currentPosition ?: 0L
        createPlayer(com.lumina.gallery.data.PlaybackPos(pos, Long.MAX_VALUE / 2, 0L))
        generation++
    }

    override fun cycleOrientation(): String {
        // 0 = automática, 1 = la orientación contraria a la inicial, 2 = la inicial (fija), y vuelta a 0.
        orientationState = (orientationState + 1) % 3
        if (orientationState == 1) {
            originalLandscape =
                resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
        }
        val landscape = when (orientationState) {
            1 -> !originalLandscape
            2 -> originalLandscape
            else -> null
        }
        requestedOrientation = when (landscape) {
            true -> ActivityInfo.SCREEN_ORIENTATION_USER_LANDSCAPE
            false -> ActivityInfo.SCREEN_ORIENTATION_USER_PORTRAIT
            null -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        return when (landscape) {
            true -> "Horizontal"
            false -> "Vertical"
            null -> "Orientación automática"
        }
    }

    // Solo se modifica el brillo de ESTA ventana: no hace falta ningún permiso ni se toca el ajuste global.
    override fun currentBrightness(): Float {
        val w = window.attributes.screenBrightness
        if (w >= 0f) return w
        return try {
            android.provider.Settings.System.getInt(contentResolver, android.provider.Settings.System.SCREEN_BRIGHTNESS) / 255f
        } catch (_: Exception) {
            0.5f
        }
    }

    override fun setBrightness(value: Float) {
        val lp = window.attributes
        lp.screenBrightness = value.coerceIn(0.01f, 1f)
        window.attributes = lp
    }

    override fun maxVolume(): Int = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
    override fun currentVolume(): Int = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
    override fun setVolume(value: Int) {
        // Solo el flujo multimedia; sin tocar llamadas ni alarmas. Sin mostrar el panel del sistema.
        audio.setStreamVolume(AudioManager.STREAM_MUSIC, value.coerceIn(0, maxVolume()), 0)
    }

    // --- Ciclo de vida --------------------------------------------------------------------

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onStop() {
        super.onStop()
        // Cambio de aplicación o bloqueo de pantalla: pausa y guarda la posición.
        player?.let {
            wasPlayingOnStop = it.playWhenReady
            it.pause()
            saveProgress(it)
        }
    }

    override fun onStart() {
        super.onStart()
        // No se reanuda sola: el usuario ve los controles en pausa y decide.
        hideSystemBars()
    }

    override fun onDestroy() {
        // Restaura brillo y orientación del sistema.
        val lp = window.attributes
        lp.screenBrightness = originalBrightness
        window.attributes = lp
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        releasePlayer()
        super.onDestroy()
    }

    private fun queryName(u: Uri): String? = try {
        contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    } catch (_: Exception) {
        null
    } ?: u.lastPathSegment

    companion object {
        const val EXTRA_TITLE = "title"
        const val EXTRA_KEY = "key"

        fun intent(context: Context, uri: Uri, title: String, key: String): Intent =
            Intent(context, VideoPlayerActivity::class.java)
                .setData(uri)
                .setAction(Intent.ACTION_VIEW)
                .putExtra(EXTRA_TITLE, title)
                .putExtra(EXTRA_KEY, key)
    }
}
