# Lumina

Galería nativa para Android (Kotlin + Jetpack Compose + Media3/ExoPlayer). Android 11 o superior (minSdk 30).

## Estado real
**El código fuente está escrito pero NO se ha compilado ni probado en un dispositivo** (el entorno donde se
creó no podía descargar el SDK de Android ni las dependencias). Es posible que la primera compilación
muestre errores menores que hay que corregir. Ninguna de las 18 pruebas de la lista de verificación se ha ejecutado.

## Compilar sin ordenador (GitHub Actions, gratis)
1. Sube esta carpeta a un repositorio de GitHub (rama `main`).
2. Pestaña **Actions → Build APK → Run workflow** (también se ejecuta en cada push).
3. Al terminar: descarga `app-debug.apk` desde **Releases → debug-latest**, o el artefacto del workflow.
4. Ábrelo en el teléfono y permite «instalar apps desconocidas» para el navegador/gestor de archivos.
Si el workflow falla, copia el error del log y se corrige.

## Compilar en un PC
JDK 17 + Android SDK (plataforma 35): `./gradlew assembleDebug` → `app/build/outputs/apk/debug/app-debug.apk`.
Instalar: `adb install -r app-debug.apk`.

## Funciones implementadas (sin verificar en dispositivo)
- Cuadrícula por fecha (Hoy, Ayer, Esta semana, Este mes, meses, años), miniaturas ajustables, duración en vídeos,
  selección múltiple, favoritos, búsqueda, filtros (tipo/fecha), orden (fecha/nombre/tamaño), conserva el scroll.
- Álbumes propios (crear, renombrar, eliminar sin borrar archivos) y carpetas del dispositivo.
- Papelera del sistema (restaurar / eliminar definitivamente), copiar y mover a carpeta, compartir; todo con diálogos
  de autorización de Android. Permisos: solo lectura de fotos y vídeos; sin Internet.
- Visor de fotos: zoom con dos dedos, doble toque, deslizar, rotar, info, presentación, favorito, eliminar.
- Reproductor Media3: controles que se ocultan solos (3–8 s), toque para mostrar/ocultar, barra de progreso con
  vista previa del tiempo (búsqueda rápida al arrastrar, exacta al soltar), ±N s, Ajustar/Rellenar/Zoom sin
  deformar, rotar (vertical/horizontal/auto), brillo de ventana y volumen multimedia con deslizadores y gestos,
  velocidad, pistas de audio y subtítulos, errores comprensibles, continuar viendo.
- Ajustes persistentes (DataStore): tema, miniaturas, orden, reproductor, gestos, reanudar, vibración.

## Limitaciones conocidas
- Sin subtítulos externos (.srt) ni decodificación por software extra; algunos códecs dependen del teléfono.
- La barra de progreso es única (sin «precisión fina» en películas de muchas horas); usa ±N s para ajustar.
- Interfaz solo en español. Papelera: la gestiona Android (~30 días).
